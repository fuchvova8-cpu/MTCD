package com.jarvis.tv

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/**
 * Look of the microphone, the poster number and the buttons of ONE screen: the overlay, the strip or the
 * results window. Every screen keeps its own values in its block of screen_layout.json (written by the
 * screen_style plugin); an empty value means "take it from the theme".
 *
 *   mic:    micSize (dp), micIcon, micFill, micActive (circle while listening)
 *   number: badgeSize (sp), badgeFill, badgeText
 *   button: btnSize (sp), btnFill, btnStroke, btnStrokeWidth (dp), btnText, btnFocus, btnRadius (dp, -1 = pill),
 *           btnActive (selected "Плитки / Список" in the overlay)
 */
class ScopeStyle(private val o: JSONObject?, private val th: Skin.Theme?) {

    fun d(k: String, def: Double): Double {
        val v = o?.opt(k)
        return if (v is Number) v.toDouble() else (v as? String)?.trim()?.replace(',', '.')?.toDoubleOrNull() ?: def
    }

    fun i(k: String, def: Int): Int = d(k, def.toDouble()).toInt()
    fun color(k: String, def: Int): Int = Skin.color(o?.optString(k, ""), def)
    private val bg: Int get() = th?.bg ?: 0xFF001018.toInt()

    // ── microphone ──
    val micSizeDp: Int get() = d("micSize", 44.0).let { if (it >= 16.0) it.toInt() else 44 }

    fun mic(ctx: Context): MicIcon = MicIcon(
        ctx, color("micIcon", Hud.TEXT), color("micActive", Hud.CYAN), color("micFill", Hud.withAlpha(Hud.CYAN, 0x30))
    )

    // ── number on a poster ──
    val badgeSp: Float get() = d("badgeSize", 12.0).let { if (it >= 6.0) it.toFloat() else 12f }

    fun badge(ctx: Context, n: Int): TextView = Badge.make(ctx, n, color("badgeFill", Hud.CYAN), color("badgeText", bg), badgeSp)
    fun badgeParams(ctx: Context): FrameLayout.LayoutParams =
        Badge.params(ctx, badgeSp, d("badgeX", 6.0).toFloat(), d("badgeY", 6.0).toFloat())

    private fun has(k: String): Boolean = !(o?.optString(k, "") ?: "").isBlank()

    /** The "ПОИСК: …" label of the results window: size, text colour, optional plate and frame. */
    fun styleTitle(tv: TextView) {
        val ctx = tv.context
        val dn = ctx.resources.displayMetrics.density
        tv.textSize = d("titleBarSize", 22.0).let { if (it >= 6.0) it.toFloat() else 22f }
        tv.setTextColor(color("titleColor", Hud.CYAN))
        val sw = d("titleStrokeWidth", 0.0).toFloat()
        if (has("titleFill") || (has("titleStroke") && sw > 0f)) {
            tv.background = Skin.roundRect(ctx, color("titleFill", 0), color("titleStroke", 0), sw, i("titleRadius", 12))
            tv.setPadding((14 * dn).toInt(), (6 * dn).toInt(), (14 * dn).toInt(), (6 * dn).toInt())
        }
    }

    // ── buttons ──
    val btnSp: Float get() = d("btnSize", 0.0).toFloat()

    private fun btnJson(): JSONObject {
        val j = JSONObject()
        val map = listOf(
            "btnRadius" to "radius", "btnFill" to "fill", "btnStroke" to "stroke",
            "btnStrokeWidth" to "strokeWidth", "btnText" to "textColor", "btnFocus" to "focusColor"
        )
        for ((from, to) in map) {
            val v = o?.opt(from) ?: continue
            if (v.toString().isNotBlank()) j.put(to, v)
        }
        return j
    }

    /** Button of the results window ("Свернуть", "Вид"). Without a skin it stays as it was. */
    fun styleButton(tv: TextView) {
        th?.let { Skin.styleButton(tv, it, btnJson()) }
        if (btnSp >= 6f) tv.textSize = btnSp
    }

    /** Height of the "Плитки / Список" pills: 40 dp at the default 14 sp, grows with the text. */
    fun pillHeightDp(): Int = Math.max(40, Math.round((if (btnSp >= 6f) btnSp else 14f) * 2.8f))

    /** "Плитки / Список" pill of the overlay: [active] = the selected one, [focused] = the remote is on it. */
    fun pillLook(ctx: Context, tv: TextView, active: Boolean, focused: Boolean) {
        val acc = Hud.CYAN
        val txt = Hud.TEXT
        val fill = if (active) color("btnActive", acc) else color("btnFill", Hud.withAlpha(acc, 0x20))
        val strokeColor = if (focused) color("btnFocus", txt) else color("btnStroke", 0)
        val strokeW = if (focused) 2f else d("btnStrokeWidth", 0.0).toFloat()
        tv.background = Skin.roundRect(ctx, fill, strokeColor, strokeW, i("btnRadius", 20))
        tv.setTextColor(if (active) bg else color("btnText", txt))
        tv.textSize = if (btnSp >= 6f) btnSp else 14f
    }
}

/** Moving the number on the posters in the editor: one drag moves all of them (the offset is shared); saved as badgeX / badgeY in dp. */
class BadgeDrag(private val scope: String, private val badges: () -> List<View>, private val d: Float) {
    private var l0 = 0
    private var t0 = 0

    fun hit(rx: Float, ry: Float): Boolean = ScopeEdit.hit(badges(), rx, ry)

    fun down() {
        val lp = badges().firstOrNull()?.layoutParams as? FrameLayout.LayoutParams
        l0 = lp?.leftMargin ?: 0
        t0 = lp?.topMargin ?: 0
    }

    fun drag(dx: Float, dy: Float, done: Boolean) {
        val list = badges()
        val first = list.firstOrNull() ?: return
        val par = first.parent as? View
        val nl = (l0 + dx).toInt().coerceIn(0, maxOf(0, (par?.width ?: 0) - first.width))
        val nt = (t0 + dy).toInt().coerceIn(0, maxOf(0, (par?.height ?: 0) - first.height))
        for (b in list) {
            val lp = b.layoutParams as? FrameLayout.LayoutParams ?: continue
            lp.leftMargin = nl
            lp.topMargin = nt
            b.layoutParams = lp
        }
        if (done) Skin.saveScope(scope, "badgeX" to Math.round(nl / d * 2.0) / 2.0, "badgeY" to Math.round(nt / d * 2.0) / 2.0)
    }
}

/** Editor mode of the overlay, the strip and the results window (opened from the plugin settings). */
object ScopeEdit {
    const val EXTRA_EDIT = "edit_mode"
    const val DEMO_TITLE = "Пример: результаты поиска"

    /** Opens the screen_style settings page on [event] (e.g. "nav:part:overlay:mic"). */
    fun settings(ctx: Context, event: String) {
        try {
            ctx.startActivity(
                Intent(ctx, PluginSettingsActivity::class.java)
                    .putExtra(PluginSettingsActivity.EXTRA_PLUGIN, "screen_style")
                    .putExtra(PluginSettingsActivity.EXTRA_TITLE, "Экран (стиль Google)")
                    .putExtra(PluginSettingsActivity.EXTRA_EVENT, event)
            )
        } catch (t: Throwable) {
            Bridge.log("SYS: не открыть настройки: ${t.message}")
        }
    }

    /** Twelve invented films, so that tiles, list, numbers and buttons can be seen while editing. */
    fun demoJson(): String {
        val apps = arrayOf("Кинопоиск", "IVI", "Okko", "YouTube")
        val a = JSONArray()
        for (n in 1..12) {
            a.put(
                JSONObject().put("title", "Пример фильма $n").put("sub", "201${n % 10} • драма")
                    .put("year", "201${n % 10}").put("rating", "7.${n % 10}").put("app", apps[n % 4])
                    .put("desc", "Здесь будет описание фильма: так выглядит список результатов с вашими настройками.")
            )
        }
        return a.toString()
    }

    /** true when the screen point (rawX, rawY) is over one of [views]. */
    fun hit(views: List<View?>, rawX: Float, rawY: Float): Boolean {
        val loc = IntArray(2)
        for (v in views) {
            if (v == null || v.visibility != View.VISIBLE || v.width == 0) continue
            v.getLocationOnScreen(loc)
            if (rawX >= loc[0] && rawX <= loc[0] + v.width && rawY >= loc[1] && rawY <= loc[1] + v.height) return true
        }
        return false
    }

    /** Hint + extra buttons + «Настройки» + «Готово», in the same look as the main-screen editor bar. */
    fun bar(ctx: Context, hint: String, extras: List<View>, onSettings: () -> Unit, onDone: () -> Unit): View {
        val d = ctx.resources.displayMetrics.density
        val th = Skin.theme()
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Skin.roundRect(ctx, Hud.withAlpha(th?.surface ?: 0xFF202124.toInt(), 0xF0), Hud.CYAN, 1f, 28)
            setPadding((18 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
            elevation = 80 * d
        }
        bar.addView(TextView(ctx).apply {
            text = hint
            textSize = 13f
            setTextColor(Hud.TEXT)
            maxLines = 2
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = (14 * d).toInt() })
        for (v in extras) bar.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = (8 * d).toInt() })
        bar.addView(Hud.button(ctx, "Настройки") { onSettings() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = (8 * d).toInt() })
        bar.addView(Hud.button(ctx, "Готово") { onDone() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return bar
    }

    fun barParams(ctx: Context): FrameLayout.LayoutParams =
        FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
            .apply { topMargin = (8 * ctx.resources.displayMetrics.density).toInt() }
}

/**
 * Panel of a screen that can be edited: with [editing] on it takes all touches itself — drag moves the panel,
 * the bottom-right corner resizes it, a long press asks for settings — except over [passThrough] views
 * (microphone, buttons), which keep working (they have their own drag) and get their own long press.
 */
class EditFrame(ctx: Context) : FrameLayout(ctx) {
    var editing = false
    var passThrough: () -> List<View?> = { emptyList() }
    var onDown: (() -> Unit)? = null
    /** (dx, dy in px since the touch began, true = the corner was grabbed, true = finger/mouse released) */
    var onDrag: ((Float, Float, Boolean, Boolean) -> Unit)? = null
    /** Long press: screen coordinates of the point. */
    var onLong: ((Float, Float) -> Unit)? = null
    /** Something that is dragged by the frame itself (the number on the posters): true if the point is on it. */
    var targetAt: (Float, Float) -> Boolean = { _, _ -> false }
    var onTargetDown: (() -> Unit)? = null
    var onTargetDrag: ((Float, Float, Boolean) -> Unit)? = null
    private var target = false

    private val d = resources.displayMetrics.density
    private var x0 = 0f
    private var y0 = 0f
    private var resizing = false
    private var moved = false
    private var long = false
    private var taken = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tri = Path()
    private val longRun = Runnable { if (!moved) { long = true; onLong?.invoke(x0, y0) } }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (!editing) return false
        if (e.actionMasked == MotionEvent.ACTION_DOWN) taken = !ScopeEdit.hit(passThrough(), e.rawX, e.rawY)
        return taken
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!editing) return super.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                x0 = e.rawX; y0 = e.rawY
                target = targetAt(e.rawX, e.rawY)
                resizing = !target && e.x >= width - 44 * d && e.y >= height - 44 * d
                moved = false
                long = false
                if (target) onTargetDown?.invoke() else onDown?.invoke()
                postDelayed(longRun, 650)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - x0
                val dy = e.rawY - y0
                if (!moved && Math.hypot(dx.toDouble(), dy.toDouble()) > 12 * d) { moved = true; removeCallbacks(longRun) }
                if (moved && !long) { if (target) onTargetDrag?.invoke(dx, dy, false) else onDrag?.invoke(dx, dy, resizing, false) }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longRun)
                if (moved && !long && e.actionMasked == MotionEvent.ACTION_UP) {
                    if (target) onTargetDrag?.invoke(e.rawX - x0, e.rawY - y0, true) else onDrag?.invoke(e.rawX - x0, e.rawY - y0, resizing, true)
                }
                moved = false
            }
        }
        return true
    }

    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        if (!editing) return
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2 * d
        paint.color = Hud.CYAN
        paint.pathEffect = DashPathEffect(floatArrayOf(10 * d, 6 * d), 0f)
        c.drawRect(d, d, width - d, height - d, paint)
        paint.pathEffect = null
        paint.style = Paint.Style.FILL
        tri.reset()
        tri.moveTo(width.toFloat(), height - 22 * d)
        tri.lineTo(width.toFloat(), height.toFloat())
        tri.lineTo(width - 22 * d, height.toFloat())
        tri.close()
        c.drawPath(tri, paint)
        // outlines of the buttons that can be dragged on their own
        val me = IntArray(2)
        getLocationOnScreen(me)
        val loc = IntArray(2)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f * d
        paint.color = 0xFFFFFFFF.toInt()
        for (v in passThrough()) {
            if (v == null || v.visibility != View.VISIBLE || v.width == 0) continue
            v.getLocationOnScreen(loc)
            val l = (loc[0] - me[0]).toFloat()
            val t = (loc[1] - me[1]).toFloat()
            c.drawRect(l, t, l + v.width, t + v.height, paint)
        }
    }
}
