package com.jarvis.tv

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/**
 * Generic settings page of a plugin (opened from the Service menu).
 * The plugin describes the page itself (see "plugin settings pages" in brain.py):
 * labels, buttons and text fields; every button press sends all field values back to the plugin.
 */
class PluginSettingsActivity : Activity() {

    private lateinit var plugin: String
    private lateinit var status: TextView
    private lateinit var box: LinearLayout
    private lateinit var scroll: ScrollView
    private val fields = LinkedHashMap<String, EditText>()
    private var loaded = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        plugin = intent.getStringExtra(EXTRA_PLUGIN) ?: ""
        val title = intent.getStringExtra(EXTRA_TITLE) ?: plugin

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Skin.theme()?.bg ?: 0xFF101418.toInt())
            setPadding(dp(24), dp(16), dp(24), dp(16))
        }
        root.addView(TextView(this).apply {
            text = title.uppercase()
            textSize = 22f
            setTextColor(Hud.CYAN)
            letterSpacing = 0.1f
        })
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Hud.AMBER)
            text = "Загрузка…"
        }
        root.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(4)
            bottomMargin = dp(8)
        })
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply {
            isFocusable = false
            addView(box)
        }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        val ev = intent.getStringExtra(EXTRA_EVENT)
        if (!ev.isNullOrEmpty()) {
            kotlin.concurrent.thread(name = "plugin-settings-nav") {
                try { TvHost.py("plugin_settings_event", plugin, ev, "{}") } catch (_: Throwable) {}
                runOnUiThread { reload() }
            }
        } else reload()
    }

    private fun reload() {
        kotlin.concurrent.thread(name = "plugin-settings") {
            val json = try {
                TvHost.py("plugin_settings_items", plugin)
            } catch (e: Throwable) {
                "[{\"type\":\"label\",\"text\":\"Ошибка: ${e.message?.replace("\"", "'")}\"}]"
            }
            runOnUiThread { render(json) }
        }
    }

    private fun render(json: String) {
        val keepY = scroll.scrollY
        box.removeAllViews()
        fields.clear()
        var first: View? = null
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val v = makeItem(arr.getJSONObject(i)) ?: continue
                if (first == null && v.isFocusable) first = v
            }
        } catch (e: Throwable) {
            status.text = "Не удалось показать настройки: ${e.message}"
        }
        loaded = true
        if (status.text.toString() == "Загрузка…") status.text = ""
        scroll.post {
            if (keepY > 0) scroll.scrollTo(0, keepY) else first?.requestFocus()
        }
    }

    private fun fieldBg(): StateListDrawable {
        fun shape(stroke: Int, w: Int) = GradientDrawable().apply {
            setColor(Skin.theme()?.surface ?: 0xFF0A0D10.toInt())
            setStroke(w, stroke)
            cornerRadius = dp(if (Skin.theme() != null) 12 else 4).toFloat()
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), shape(Hud.CYAN, dp(2)))
            addState(intArrayOf(), shape(Skin.theme()?.focus ?: 0xFF2A3A48.toInt(), dp(1)))
        }
    }

    private fun makeItem(o: JSONObject): View? {
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        when (o.optString("type")) {
            "label" -> {
                val t = TextView(this).apply {
                    text = o.optString("text")
                    textSize = 14f
                    setTextColor(Hud.MUTED)
                }
                box.addView(t, LinearLayout.LayoutParams(match, wrap).apply { bottomMargin = dp(8) })
                return t
            }
            "button" -> {
                val id = o.optString("id")
                val b = Hud.button(this, o.optString("label")) { onButton(id) }
                box.addView(b, LinearLayout.LayoutParams(wrap, wrap).apply { bottomMargin = dp(8) })
                return b
            }
            "color" -> return makeColor(o)
            "text" -> {
                val id = o.optString("id")
                val multi = o.optBoolean("multiline", false)
                box.addView(TextView(this).apply {
                    text = o.optString("label")
                    textSize = 15f
                    setTextColor(Hud.TEXT)
                }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(8) })
                val e = EditText(this).apply {
                    setText(o.optString("value"))
                    hint = o.optString("hint")
                    setTextColor(Hud.TEXT)
                    setHintTextColor(Hud.MUTED)
                    textSize = 16f
                    background = fieldBg()
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    if (multi) {
                        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                        setSingleLine(false)
                        minLines = 2
                        maxLines = Int.MAX_VALUE
                        gravity = Gravity.TOP or Gravity.START
                    } else {
                        inputType = InputType.TYPE_CLASS_TEXT
                        setSingleLine(true)
                    }
                }
                fields[id] = e
                box.addView(e, LinearLayout.LayoutParams(match, wrap))
                return e
            }
        }
        return null
    }

    /** Colour mixer: swatch, four equalizer bars (R G B A), hex field. Empty hex = "use the default". */
    private fun makeColor(o: JSONObject): View {
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val id = o.optString("id")
        val value = o.optString("value")
        val def = Skin.color(o.optString("default"), Color.WHITE)
        box.addView(TextView(this).apply {
            text = o.optString("label")
            textSize = 15f
            setTextColor(Hud.TEXT)
        }, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(10) })

        var argb = Skin.color(value, def)
        val hex = EditText(this).apply {
            setText(value)
            hint = o.optString("default").ifEmpty { "#RRGGBB" }
            setTextColor(Hud.TEXT)
            setHintTextColor(Hud.MUTED)
            textSize = 16f
            background = fieldBg()
            setPadding(dp(10), dp(8), dp(10), dp(8))
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        fields[id] = hex
        val swatch = View(this)
        fun paintSwatch() {
            swatch.background = Skin.roundRect(this, argb, 0xFFFFFFFF.toInt(), 1f, 10)
        }
        paintSwatch()

        var syncing = false
        val bars = ArrayList<EqBar>()
        fun writeHex() {
            syncing = true
            val a = Color.alpha(argb)
            hex.setText(if (a == 255) String.format("#%02X%02X%02X", Color.red(argb), Color.green(argb), Color.blue(argb))
                        else String.format("#%02X%02X%02X%02X", a, Color.red(argb), Color.green(argb), Color.blue(argb)))
            syncing = false
        }
        fun setBars() { bars[0].value = Color.red(argb); bars[1].value = Color.green(argb); bars[2].value = Color.blue(argb); bars[3].value = Color.alpha(argb) }
        val tints = intArrayOf(0xFFFF5252.toInt(), 0xFF4CAF50.toInt(), 0xFF448AFF.toInt(), 0xFFE0E0E0.toInt())
        val init = intArrayOf(Color.red(argb), Color.green(argb), Color.blue(argb), Color.alpha(argb))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(swatch, LinearLayout.LayoutParams(dp(56), dp(120)).apply { marginEnd = dp(14) })
        for (i in 0 until 4) {
            val bar = EqBar(this, tints[i], init[i]) { v ->
                argb = when (i) {
                    0 -> Color.argb(Color.alpha(argb), v, Color.green(argb), Color.blue(argb))
                    1 -> Color.argb(Color.alpha(argb), Color.red(argb), v, Color.blue(argb))
                    2 -> Color.argb(Color.alpha(argb), Color.red(argb), Color.green(argb), v)
                    else -> Color.argb(v, Color.red(argb), Color.green(argb), Color.blue(argb))
                }
                paintSwatch()
                writeHex()
            }
            bars.add(bar)
            row.addView(bar, LinearLayout.LayoutParams(wrap, wrap).apply { marginEnd = dp(6) })
        }
        val side = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        side.addView(hex, LinearLayout.LayoutParams(dp(190), wrap))
        side.addView(Hud.button(this, "Сброс") {
            hex.setText("")
            argb = def
            paintSwatch()
            setBars()
        }, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(8) })
        row.addView(side, LinearLayout.LayoutParams(wrap, wrap).apply { marginStart = dp(12) })
        hex.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (syncing) return
                val t = s?.toString()?.trim().orEmpty()
                val parsed = try { if (t.length >= 7) Color.parseColor(if (t.startsWith("#")) t else "#$t") else null } catch (_: Throwable) { null }
                if (parsed != null) { argb = parsed; paintSwatch(); setBars() }
            }
        })
        box.addView(row, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(4) })
        return bars[0]
    }

    private fun collect(): String {
        val o = JSONObject()
        for ((k, v) in fields) o.put(k, v.text.toString())
        return o.toString()
    }

    private fun onButton(id: String) {
        val values = collect()
        status.setTextColor(Hud.AMBER)
        status.text = "Выполняю…"
        kotlin.concurrent.thread(name = "plugin-settings") {
            val res = try {
                JSONObject(TvHost.py("plugin_settings_event", plugin, id, values))
            } catch (e: Throwable) {
                JSONObject().put("message", "Ошибка: ${e.message}").put("refresh", false)
            }
            runOnUiThread {
                val msg = res.optString("message")
                status.setTextColor(Hud.CYAN)
                status.text = msg
                if (msg.isNotEmpty()) Bridge.log("SYS: $plugin: $msg")
                if (res.optBoolean("refresh")) reload()
                val launch = res.optString("launch")
                if (launch.isNotEmpty()) launchEditor(launch)
            }
        }
    }

    /** Opens the overlay / strip / results window in the editor mode (button of the screen_style plugin). */
    private fun launchEditor(which: String) {
        val cls = when (which) {
            "bar" -> MicBarActivity::class.java
            "results" -> ResultsActivity::class.java
            else -> OverlayActivity::class.java
        }
        try {
            startActivity(android.content.Intent(this, cls).putExtra(ScopeEdit.EXTRA_EDIT, true))
        } catch (e: Throwable) {
            status.text = "Не удалось открыть редактор: ${e.message}"
        }
    }

    /** Back from the editor: its drags changed the layout file, show the new values (not the stale fields). */
    override fun onRestart() {
        super.onRestart()
        if (loaded) reload()
    }

    /** Leaving the page saves the typed values (plugin gets the "__leave__" event). */
    override fun onStop() {
        if (loaded && fields.isNotEmpty() && !isChangingConfigurations) {
            val values = collect()
            val name = plugin
            kotlin.concurrent.thread(name = "plugin-settings") {
                try {
                    TvHost.py("plugin_settings_event", name, "__leave__", values)
                } catch (e: Throwable) {
                    Bridge.log("SYS: $name: сохранение при выходе: ${e.message}")
                }
            }
        }
        super.onStop()
    }

    companion object {
        const val EXTRA_PLUGIN = "plugin"
        const val EXTRA_TITLE = "title"
        const val EXTRA_EVENT = "event"
    }
}
