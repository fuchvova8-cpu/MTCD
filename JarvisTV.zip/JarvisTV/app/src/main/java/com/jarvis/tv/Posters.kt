package com.jarvis.tv

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.LruCache
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Loads poster images (http/https or content:// URIs from search providers) with a small memory cache. */
object Posters {

    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val pool = Executors.newFixedThreadPool(4)
    private val mainH = android.os.Handler(android.os.Looper.getMainLooper())

    /** Calls [cb] on the main thread with the bitmap, or null when it can't be loaded. */
    fun load(ctx: android.content.Context, url: String, w: Int, h: Int, cb: (Bitmap?) -> Unit) {
        cache.get(url)?.let { cb(it); return }
        pool.execute {
            val bmp = try {
                fetch(ctx, url, w, h)
            } catch (e: Throwable) {
                Bridge.log("SYS: " + "Постер не загрузился: ${e.javaClass.simpleName}: ${e.message} ($url)")
                null
            }
            if (bmp != null) cache.put(url, bmp)
            mainH.post { cb(bmp) }
        }
    }

    private fun fetch(ctx: android.content.Context, url: String, w: Int, h: Int): Bitmap? {
        val bytes: ByteArray = when {
            url.startsWith("http://") || url.startsWith("https://") -> {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 10000
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 9; TV) JarvisTV")
                try {
                    c.inputStream.use { it.readBytes() }
                } finally {
                    c.disconnect()
                }
            }
            url.startsWith("content://") || url.startsWith("file://") || url.startsWith("android.resource://") ->
                ctx.contentResolver.openInputStream(Uri.parse(url))?.use { it.readBytes() } ?: return null
            else -> return null
        }
        if (bytes.isEmpty() || bytes.size > 8_000_000) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        if (o.outWidth > 0 && o.outHeight > 0) {
            while (o.outWidth / (sample * 2) >= w && o.outHeight / (sample * 2) >= h) sample *= 2
        }
        val d = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, d)
    }
}
