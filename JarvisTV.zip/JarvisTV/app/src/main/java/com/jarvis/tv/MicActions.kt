package com.jarvis.tv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/** Invisible quick-action entry (TV Quick Actions): does one thing with the microphone and closes at once. */
abstract class MicActionActivity : Activity() {
    protected abstract fun act()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!VoiceLoop.hasPermission()) {
            Toast.makeText(this, "JARVIS: нет разрешения на микрофон", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
        } else {
            JarvisService.start(this)
            act()
        }
        finish()
    }
}

/** The microphone button: one phrase; a second press stops listening. */
class MicHiddenActivity : MicActionActivity() {
    override fun act() = VoiceLoop.listenOnce()
}

/** Switches the microphone mode: by button <-> always on. */
class MicModeToggleActivity : MicActionActivity() {
    override fun act() = MicMode.toggleMode()
}

/** Mode "по кнопке". */
class MicModeButtonActivity : MicActionActivity() {
    override fun act() = MicMode.setMode(MicMode.Mode.PTT)
}

/** Mode "постоянно". */
class MicModeLiveActivity : MicActionActivity() {
    override fun act() = MicMode.setMode(MicMode.Mode.LIVE)
}

/** Continuous listening on/off (from "по кнопке" it switches to "постоянно"). */
class ToggleActivity : MicActionActivity() {
    override fun act() = MicMode.toggleLiveOn()
}

class MicOnActivity : MicActionActivity() {
    override fun act() = MicMode.setLiveOn(true)
}

class MicOffActivity : MicActionActivity() {
    override fun act() = MicMode.setLiveOn(false)
}

/** Search results from the video services: hide if shown, bring back if hidden. No microphone permission needed. */
open class ResultsActionActivity : Activity() {
    protected open fun act() {
        if (TvHost.resultsVisible()) TvHost.hideResults()
        else if (!TvHost.reopenResults()) Toast.makeText(this, "JARVIS: пока нет результатов поиска", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        act()
        finish()
    }
}

class ResultsToggleActivity : ResultsActionActivity()

class ResultsShowActivity : ResultsActionActivity() {
    override fun act() {
        if (!TvHost.resultsVisible() && !TvHost.reopenResults())
            Toast.makeText(this, "JARVIS: пока нет результатов поиска", Toast.LENGTH_SHORT).show()
    }
}

class ResultsHideActivity : ResultsActionActivity() {
    override fun act() = TvHost.hideResults()
}
