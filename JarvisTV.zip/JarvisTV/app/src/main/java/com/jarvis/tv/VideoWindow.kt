package com.jarvis.tv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import org.json.JSONObject
import java.io.File

/**
 * Video as a floating window drawn over everything (needs "draw over other apps").
 * It does not belong to any activity, so it keeps playing while JARVIS is minimised.
 *
 * Mouse / touch: drag the picture to move, drag the corner triangle to resize, wheel = scale,
 * click = play / pause. YouTube-like controls fade in on hover and fade out after a few seconds.
 * Position, size, colours and which buttons exist come from the "video" part of screen_layout.json
 * (screen_style plugin). When the permission is missing the old in-screen player is used instead.
 */
object VideoWindow {
    private val main = Handler(Looper.getMainLooper())
    private var win: Win? = null
    private var lp: WindowManager.LayoutParams? = null
    private var player: ExoPlayer? = null
    private var imageMode = false
    private var fullscreen = false
    private var prevX = 0
    private var prevY = 0
    private var prevW = 0
    private var prevH = 0
    private var cfgMt = 0L

    @Volatile var active = false
        private set

    /** Called on the main thread when a window appears / disappears (MainActivity hides its own buttons). */
    @Volatile var listener: ((Boolean) -> Unit)? = null

    /** Called (main thread) whenever the window moves, changes size, opens or closes. */
    @Volatile var geoListener: (() -> Unit)? = null

    /** Screen rectangle of the window, null while there is none. */
    fun bounds(): android.graphics.Rect? {
        val l = lp ?: return null
        if (!active) return null
        return android.graphics.Rect(l.x, l.y, l.x + l.width, l.y + l.height)
    }

    private fun geo() { try { geoListener?.invoke() } catch (_: Throwable) {} }

    private fun wm() = Bridge.app.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private fun screen(): Point = Point().also {
        try { wm().defaultDisplay.getRealSize(it) } catch (_: Throwable) { it.set(1920, 1080) }
    }

    fun enabled(): Boolean = MicIndicator.canDraw() && Skin.videoCfg().optString("mode", "window") != "legacy"

    // ── public API (any thread) ──
    fun open(src: String, title: String, muted: Boolean, audio: String, onFail: () -> Unit) {
        main.post {
            try {
                closeNow()
                val factory = DefaultHttpDataSource.Factory()
                    .setUserAgent("Mozilla/5.0 (Linux; Android 9; TV) AppleWebKit/537.36 Chrome/120 Safari/537.36")
                    .setAllowCrossProtocolRedirects(true)
                val msf = DefaultMediaSourceFactory(factory)
                fun item(s: String) = MediaItem.fromUri(if (s.contains("://")) Uri.parse(s) else Uri.fromFile(File(s)))
                val video = msf.createMediaSource(item(src))
                val source = if (audio.isNotEmpty()) MergingMediaSource(video, msf.createMediaSource(item(audio))) else video
                val p = ExoPlayer.Builder(Bridge.app).build()
                p.setMediaSource(source)
                p.volume = if (muted) 0f else 1f
                val w = ensureWindow()
                player = p
                imageMode = false
                w.bindVideo(p, title)
                p.prepare()
                p.playWhenReady = true
                setActive(true)
            } catch (t: Throwable) {
                fail(t)
                onFail()
            }
        }
    }

    private fun fail(t: Throwable) {
        val text = "Окно видео не открылось: ${t.javaClass.simpleName}: ${t.message}"
        Bridge.log("SYS: $text")
        try { android.widget.Toast.makeText(Bridge.app, text, android.widget.Toast.LENGTH_LONG).show() } catch (_: Throwable) {}
        closeNow()
    }

    fun openImage(path: String, title: String, onFail: () -> Unit) {
        main.post {
            try {
                closeNow()
                val w = ensureWindow()
                imageMode = true
                w.bindImage(path, title)
                setActive(true)
            } catch (t: Throwable) {
                fail(t)
                onFail()
            }
        }
    }

    fun close() { main.post { closeNow() } }
    fun mute(m: Boolean) { main.post { player?.volume = if (m) 0f else 1f } }
    fun pause(paused: Boolean) { main.post { player?.playWhenReady = !paused } }

    fun seek(seconds: Double, relative: Boolean) {
        main.post {
            val p = player ?: return@post
            val ms = (seconds * 1000).toLong()
            p.seekTo(if (relative) (p.currentPosition + ms).coerceAtLeast(0) else ms.coerceAtLeast(0))
        }
    }

    fun toggle() { main.post { togglePause() } }

    /** Main thread only (Bridge.videoState hops over). */
    fun state(): String {
        val o = JSONObject()
        val p = player
        when {
            p != null -> {
                o.put("kind", "video")
                o.put("position", p.currentPosition / 1000.0)
                o.put("duration", if (p.duration > 0) p.duration / 1000.0 else 0.0)
                o.put("paused", !p.playWhenReady)
            }
            imageMode -> { o.put("kind", "image"); o.put("position", 0.0); o.put("duration", 0.0); o.put("paused", false) }
            else -> { o.put("kind", ""); o.put("position", 0.0); o.put("duration", 0.0); o.put("paused", false) }
        }
        return o.toString()
    }

    // ── internals (main thread) ──
    private fun setActive(a: Boolean) {
        if (active == a) return
        active = a
        try { listener?.invoke(a) } catch (_: Throwable) {}
        geo()
    }

    private fun togglePause() { player?.let { it.playWhenReady = !it.playWhenReady } }

    private fun closeNow() {
        main.removeCallbacks(tick)
        main.removeCallbacks(persistRun)
        try { player?.release() } catch (_: Throwable) {}
        player = null
        win?.let { try { wm().removeView(it) } catch (_: Throwable) {} }
        win = null
        lp = null
        imageMode = false
        fullscreen = false
        setActive(false)
    }

    private fun minW(s: Point): Int = (s.x * 0.15).toInt().coerceAtLeast(220)
    private fun minH(s: Point): Int = minW(s) * 9 / 16

    /** x, y, w, h in pixels for the saved settings. */
    private fun rectPx(c: JSONObject): IntArray {
        val s = screen()
        if (c.optString("mode", "window") == "full") return intArrayOf(0, 0, s.x, s.y)
        val w = (s.x * c.optDouble("w", 60.0) / 100.0).toInt().coerceIn(minW(s), s.x)
        val h = (s.y * c.optDouble("h", 62.0) / 100.0).toInt().coerceIn(minH(s), s.y)
        val x = (s.x * c.optDouble("x", 20.0) / 100.0).toInt().coerceIn(0, (s.x - w).coerceAtLeast(0))
        val y = (s.y * c.optDouble("y", 14.0) / 100.0).toInt().coerceIn(0, (s.y - h).coerceAtLeast(0))
        return intArrayOf(x, y, w, h)
    }

    private fun ensureWindow(): Win {
        win?.let { return it }
        val c = Skin.videoCfg()
        val r = rectPx(c)
        val params = WindowManager.LayoutParams(
            r[2], r[3],
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = r[0]
            y = r[1]
            alpha = (c.optInt("opacity", 100).coerceIn(20, 100)) / 100f
        }
        val w = Win(Bridge.app)
        w.applyCfg(c)
        wm().addView(w, params)
        win = w
        lp = params
        cfgMt = Skin.fileMt()
        main.removeCallbacks(tick)
        main.postDelayed(tick, 400)
        return w
    }

    /** The plugin saved new settings while the window is up. */
    private fun applyCfgNow() {
        val w = win ?: return
        val l = lp ?: return
        val c = Skin.videoCfg()
        if (c.optString("mode", "window") == "legacy") return
        if (!fullscreen) {
            val r = rectPx(c)
            l.x = r[0]; l.y = r[1]; l.width = r[2]; l.height = r[3]
        }
        l.alpha = (c.optInt("opacity", 100).coerceIn(20, 100)) / 100f
        try { wm().updateViewLayout(w, l) } catch (_: Throwable) {}
        w.applyCfg(c)
        geo()
    }

    private val tick = object : Runnable {
        override fun run() {
            val w = win ?: return
            val m = Skin.fileMt()
            if (m != cfgMt) { cfgMt = m; applyCfgNow() }
            w.refresh()
            main.postDelayed(this, 400)
        }
    }

    private val persistRun = Runnable { persist() }

    private fun persistSoon() {
        main.removeCallbacks(persistRun)
        main.postDelayed(persistRun, 400)
    }

    private fun persist() {
        val l = lp ?: return
        if (fullscreen) return
        val s = screen()
        Skin.saveVideo(
            l.x * 100.0 / s.x, l.y * 100.0 / s.y,
            l.width * 100.0 / s.x, l.height * 100.0 / s.y
        )
        cfgMt = Skin.fileMt()
    }

    private fun scaleBy(f: Double) {
        val w = win ?: return
        val l = lp ?: return
        if (fullscreen) return
        val s = screen()
        val cx = l.x + l.width / 2.0
        val cy = l.y + l.height / 2.0
        val nw = (l.width * f).toInt().coerceIn(minW(s), s.x)
        val nh = (l.height * f).toInt().coerceIn(minH(s), s.y)
        l.width = nw
        l.height = nh
        l.x = (cx - nw / 2.0).toInt().coerceIn(0, (s.x - nw).coerceAtLeast(0))
        l.y = (cy - nh / 2.0).toInt().coerceIn(0, (s.y - nh).coerceAtLeast(0))
        try { wm().updateViewLayout(w, l) } catch (_: Throwable) {}
        persistSoon()
        geo()
    }

    private fun toggleFullscreen() {
        val w = win ?: return
        val l = lp ?: return
        val s = screen()
        if (!fullscreen) {
            prevX = l.x; prevY = l.y; prevW = l.width; prevH = l.height
            l.x = 0; l.y = 0; l.width = s.x; l.height = s.y
            fullscreen = true
        } else {
            l.x = prevX; l.y = prevY; l.width = prevW; l.height = prevH
            fullscreen = false
        }
        try { wm().updateViewLayout(w, l) } catch (_: Throwable) {}
        w.applyCfg(Skin.videoCfg())
        geo()
    }

    private fun fmt(ms: Long): String {
        if (ms <= 0) return "0:00"
        val t = ms / 1000
        val h = t / 3600
        val m = (t % 3600) / 60
        val s = t % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%d:%02d", m, s)
    }

    // ═══════════════ the window ═══════════════
    private enum class K { PLAY, PAUSE, BACK, FWD, VOL, MUTE, MINUS, PLUS, FULL, EXIT, CLOSE }

    private class Win(ctx: Context) : FrameLayout(ctx) {
        private val d = resources.displayMetrics.density
        private fun dp(v: Float): Int = (v * d).toInt()

        private val tex = TextureView(ctx)
        private val img = ImageView(ctx).apply { scaleType = ImageView.ScaleType.FIT_CENTER; visibility = View.GONE }
        private var controls: FrameLayout? = null
        private var titleBox: FrameLayout? = null
        private var titleView: TextView? = null
        private var timeView: TextView? = null
        private var playBtn: Icon? = null
        private var volBtn: Icon? = null
        private var fullBtn: Icon? = null
        private var progress: Progress? = null
        private val videoOnly = ArrayList<View>()
        private val handle = HandleView(ctx)
        private var cfg = JSONObject()
        private var title = ""
        private var vw = 0
        private var vh = 0
        private var shown = true
        private var lastShow = SystemClock.uptimeMillis()

        // drag / resize state
        private var touchMode = 0
        private var downRX = 0f
        private var downRY = 0f
        private var startX = 0
        private var startY = 0
        private var startW = 0
        private var startH = 0
        private var moved = false

        init {
            setBackgroundColor(Color.BLACK)
            addView(tex, LayoutParams(-1, -1, Gravity.CENTER))
            addView(img, LayoutParams(-1, -1))
            addView(handle, LayoutParams(dp(26f), dp(26f), Gravity.BOTTOM or Gravity.END))
        }

        fun bindVideo(p: ExoPlayer, t: String) {
            title = t
            img.visibility = View.GONE
            tex.visibility = View.VISIBLE
            for (v in videoOnly) v.visibility = View.VISIBLE
            progress?.visibility = View.VISIBLE
            titleView?.text = t
            p.setVideoTextureView(tex)
            p.addListener(object : Player.Listener {
                override fun onVideoSizeChanged(size: VideoSize) {
                    vw = (size.width * size.pixelWidthHeightRatio).toInt()
                    vh = size.height
                    fit()
                }

                override fun onPlayerError(error: PlaybackException) {
                    Bridge.log("SYS: видео: ${error.errorCodeName}")
                }
            })
            showControls()
        }

        fun bindImage(path: String, t: String) {
            title = t
            tex.visibility = View.GONE
            img.visibility = View.VISIBLE
            img.setImageURI(Uri.fromFile(File(path)))
            for (v in videoOnly) v.visibility = View.GONE
            progress?.visibility = View.GONE
            timeView?.text = ""
            titleView?.text = t
            showControls()
        }

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            super.onSizeChanged(w, h, ow, oh)
            fit()
        }

        private fun fit() {
            val w = width
            val h = height
            if (w <= 0 || h <= 0) return
            val l = tex.layoutParams as LayoutParams
            if (vw <= 0 || vh <= 0) {
                l.width = w; l.height = h
            } else {
                val sc = Math.min(w.toDouble() / vw, h.toDouble() / vh)
                l.width = (vw * sc).toInt().coerceAtLeast(1)
                l.height = (vh * sc).toInt().coerceAtLeast(1)
            }
            l.gravity = Gravity.CENTER
            tex.layoutParams = l
        }

        private fun flag(k: String): Boolean = cfg.optInt(k, 1) != 0

        // ── look & buttons from the settings ──
        fun applyCfg(c: JSONObject) {
            cfg = c
            val accent = Skin.color(c.optString("accent"), 0xFFFF0000.toInt())
            val iconCol = Skin.color(c.optString("iconColor"), Color.WHITE)
            val barCol = Skin.color(c.optString("barColor"), 0xB3000000.toInt())
            val titleCol = Skin.color(c.optString("titleColor"), Color.WHITE)
            val frameCol = Skin.color(c.optString("frameColor"), 0)
            val full = fullscreen || c.optString("mode", "window") == "full"
            val r = if (full) 0f else c.optInt("radius", 14).coerceAtLeast(0) * d
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = r
                if (frameCol != 0 && !full) setStroke(dp(2f), frameCol)
            }
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, r)
                }
            }
            clipToOutline = true

            controls?.let { removeView(it) }
            titleBox?.let { removeView(it) }
            videoOnly.clear()

            val isz = dp(c.optInt("iconSize", 34).toFloat()).coerceIn(dp(20f), dp(80f))
            val hover = { showControls() }

            // title (top)
            val tb = FrameLayout(context)
            tb.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(barCol, 0))
            val tv = TextView(context).apply {
                text = title
                textSize = 15f
                setTextColor(titleCol)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(dp(14f), dp(10f), dp(14f), dp(26f))
            }
            tb.addView(tv, LayoutParams(-1, -2))
            tb.visibility = if (flag("showTitle")) View.VISIBLE else View.GONE
            addView(tb, 2, LayoutParams(-1, -2, Gravity.TOP))
            titleBox = tb
            titleView = tv

            // bottom: progress line + buttons
            val col = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(8f), 0, dp(36f), dp(4f))
            }
            val pr = Progress(context, accent) { frac -> seekToFraction(frac) }
            progress = pr
            col.addView(pr, LinearLayout.LayoutParams(-1, dp(22f)))

            val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            fun add(k: K, videoOnlyBtn: Boolean, onClick: () -> Unit): Icon {
                val b = Icon(context, k, iconCol, onClick, hover)
                row.addView(b, LinearLayout.LayoutParams(isz, isz).apply { marginEnd = dp(2f) })
                if (videoOnlyBtn) videoOnly.add(b)
                return b
            }
            playBtn = add(K.PLAY, true) { togglePause() }
            if (flag("showSeek")) {
                add(K.BACK, true) { seekRel(-10) }
                add(K.FWD, true) { seekRel(10) }
            }
            volBtn = if (flag("showVolume")) add(K.VOL, true) { player?.let { it.volume = if (it.volume > 0f) 0f else 1f } } else null
            val tm = TextView(context).apply {
                textSize = 13f
                setTextColor(iconCol)
                setPadding(dp(8f), 0, dp(8f), 0)
                maxLines = 1
            }
            timeView = tm
            row.addView(tm, LinearLayout.LayoutParams(0, -2, 1f))
            videoOnly.add(tm)
            if (flag("showScale")) {
                add(K.MINUS, false) { scaleBy(1 / 1.12) }
                add(K.PLUS, false) { scaleBy(1.12) }
            }
            fullBtn = if (flag("showFull")) add(if (fullscreen) K.EXIT else K.FULL, false) {
                toggleFullscreen()
            } else null
            add(K.CLOSE, false) { closeNow() }
            col.addView(row, LinearLayout.LayoutParams(-1, -2))

            val box = FrameLayout(context)
            box.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0, barCol))
            box.setPadding(0, dp(34f), 0, 0)
            box.addView(col, LayoutParams(-1, -2))
            addView(box, 2, LayoutParams(-1, -2, Gravity.BOTTOM))
            controls = box

            handle.color = iconCol
            if (imageMode) {
                for (v in videoOnly) v.visibility = View.GONE
                pr.visibility = View.GONE
            }
            fit()
            showControls()
        }

        private val imageMode: Boolean get() = this@Win.img.visibility == View.VISIBLE

        private fun seekToFraction(f: Double) {
            val p = player ?: return
            val dur = p.duration
            if (dur > 0) p.seekTo((dur * f).toLong())
        }

        private fun seekRel(sec: Int) {
            val p = player ?: return
            p.seekTo((p.currentPosition + sec * 1000L).coerceAtLeast(0))
        }

        // ── controls fade ──
        fun showControls() {
            lastShow = SystemClock.uptimeMillis()
            if (shown) return
            shown = true
            controls?.visibility = View.VISIBLE
            if (cfg.optInt("showTitle", 1) != 0) titleBox?.visibility = View.VISIBLE
            handle.visibility = if (fullscreen) View.GONE else View.VISIBLE
        }

        private fun hideControls() {
            if (!shown) return
            shown = false
            controls?.visibility = View.GONE
            titleBox?.visibility = View.GONE
            handle.visibility = View.GONE
        }

        /** Called every ~400 ms. */
        fun refresh() {
            val p = player
            var playing = true
            if (p != null && !imageMode) {
                val dur = p.duration
                val pos = p.currentPosition
                progress?.set(
                    if (dur > 0) pos.toFloat() / dur else 0f,
                    if (dur > 0) p.bufferedPosition.toFloat() / dur else 0f
                )
                timeView?.text = fmt(pos) + " / " + fmt(dur)
                playing = p.playWhenReady && p.playbackState != Player.STATE_ENDED
                playBtn?.kind = if (playing) K.PAUSE else K.PLAY
                volBtn?.kind = if (p.volume > 0f) K.VOL else K.MUTE
            }
            fullBtn?.kind = if (fullscreen) K.EXIT else K.FULL
            val ah = cfg.optInt("autoHide", 3)
            if (ah > 0 && playing && progress?.scrubbing != true &&
                SystemClock.uptimeMillis() - lastShow > ah * 1000L) hideControls()
            else if (!playing) showControls()
        }

        // ── mouse / touch on the picture ──
        override fun onTouchEvent(e: MotionEvent): Boolean {
            val l = lp ?: return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRX = e.rawX; downRY = e.rawY
                    startX = l.x; startY = l.y; startW = l.width; startH = l.height
                    moved = false
                    touchMode = if (!fullscreen && e.x > width - dp(44f) && e.y > height - dp(44f)) 2 else 1
                    shown = false
                    showControls()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downRX
                    val dy = e.rawY - downRY
                    if (!moved && Math.hypot(dx.toDouble(), dy.toDouble()) < dp(8f)) return true
                    moved = true
                    if (fullscreen) return true
                    val s = screen()
                    if (touchMode == 2) {
                        l.width = (startW + dx).toInt().coerceIn(minW(s), (s.x - l.x).coerceAtLeast(minW(s)))
                        l.height = (startH + dy).toInt().coerceIn(minH(s), (s.y - l.y).coerceAtLeast(minH(s)))
                    } else {
                        l.x = (startX + dx).toInt().coerceIn(0, (s.x - l.width).coerceAtLeast(0))
                        l.y = (startY + dy).toInt().coerceIn(0, (s.y - l.height).coerceAtLeast(0))
                    }
                    try { wm().updateViewLayout(this, l) } catch (_: Throwable) {}
                    lastShow = SystemClock.uptimeMillis()
                    geo()
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePause() else persist()
                    touchMode = 0
                }
                MotionEvent.ACTION_CANCEL -> touchMode = 0
            }
            return true
        }

        override fun onGenericMotionEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_SCROLL -> {
                    val v = e.getAxisValue(MotionEvent.AXIS_VSCROLL)
                    if (v != 0f) { scaleBy(if (v > 0) 1.08 else 1 / 1.08); showControls(); return true }
                }
                MotionEvent.ACTION_HOVER_MOVE, MotionEvent.ACTION_HOVER_ENTER -> showControls()
            }
            return super.onGenericMotionEvent(e)
        }
    }

    // ═══════════════ small views ═══════════════
    /** Resize triangle in the bottom-right corner. */
    private class HandleView(ctx: Context) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        var color: Int = Color.WHITE
            set(v) { field = v; invalidate() }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            path.reset()
            path.moveTo(w, 0f)
            path.lineTo(w, h)
            path.lineTo(0f, h)
            path.close()
            paint.style = Paint.Style.FILL
            paint.color = (color and 0x00FFFFFF) or 0xAA000000.toInt()
            c.drawPath(path, paint)
        }
    }

    /** Seek line: grey track, lighter buffered part, accent played part and a dot. */
    private class Progress(ctx: Context, private val accent: Int, private val onSeek: (Double) -> Unit) : View(ctx) {
        private val d = resources.displayMetrics.density
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var frac = 0f
        private var buf = 0f
        private var scrub = -1f
        val scrubbing: Boolean get() = scrub >= 0f

        fun set(f: Float, b: Float) {
            if (scrub >= 0f) return
            frac = f.coerceIn(0f, 1f)
            buf = b.coerceIn(0f, 1f)
            invalidate()
        }

        override fun onHoverChanged(hovered: Boolean) {
            super.onHoverChanged(hovered)
            invalidate()
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val big = isHovered || scrub >= 0f
            val th = (if (big) 5f else 3f) * d
            val cy = h / 2f
            val pad = 6f * d
            val x0 = pad
            val x1 = w - pad
            val f = if (scrub >= 0f) scrub else frac
            paint.style = Paint.Style.FILL
            paint.color = 0x55FFFFFF
            c.drawRoundRect(x0, cy - th / 2, x1, cy + th / 2, th, th, paint)
            paint.color = 0x88FFFFFF.toInt()
            c.drawRoundRect(x0, cy - th / 2, x0 + (x1 - x0) * buf, cy + th / 2, th, th, paint)
            paint.color = accent
            val px = x0 + (x1 - x0) * f
            c.drawRoundRect(x0, cy - th / 2, px, cy + th / 2, th, th, paint)
            c.drawCircle(px, cy, (if (big) 8f else 6f) * d, paint)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val pad = 6f * d
            fun at() = ((e.x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> { scrub = at(); invalidate(); return true }
                MotionEvent.ACTION_UP -> {
                    val f = at()
                    scrub = -1f
                    frac = f
                    onSeek(f.toDouble())
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_CANCEL -> { scrub = -1f; invalidate(); return true }
            }
            return true
        }
    }

    /** One round button whose symbol is drawn in code (no image files needed). */
    private class Icon(
        ctx: Context,
        k: K,
        private val color: Int,
        onClick: () -> Unit,
        private val onHover: () -> Unit
    ) : View(ctx) {
        var kind: K = k
            set(v) { if (field != v) { field = v; invalidate() } }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val line = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        private val box = RectF()

        init {
            isClickable = true
            setOnClickListener { onClick() }
            line.style = Paint.Style.STROKE
            line.strokeCap = Paint.Cap.ROUND
            fill.style = Paint.Style.FILL
            fill.textAlign = Paint.Align.CENTER
        }

        override fun onHoverChanged(hovered: Boolean) {
            super.onHoverChanged(hovered)
            invalidate()
            if (hovered) onHover()
        }

        private fun corner(c: Canvas, x: Float, y: Float, sx: Float, sy: Float, arm: Float) {
            c.drawLine(x, y, x + sx * arm, y, line)
            c.drawLine(x, y, x, y + sy * arm, line)
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val s = Math.min(w, h)
            val cx = w / 2f
            val cy = h / 2f
            val r = s * 0.30f
            if (isHovered || isPressed) {
                fill.color = 0x33FFFFFF
                c.drawCircle(cx, cy, s / 2f * 0.95f, fill)
            }
            fill.color = color
            line.color = color
            line.strokeWidth = Math.max(2f, s * 0.07f)
            when (kind) {
                K.PLAY -> {
                    path.reset()
                    path.moveTo(cx - r * 0.6f, cy - r)
                    path.lineTo(cx - r * 0.6f, cy + r)
                    path.lineTo(cx + r * 0.95f, cy)
                    path.close()
                    c.drawPath(path, fill)
                }
                K.PAUSE -> {
                    c.drawRect(cx - r * 0.75f, cy - r, cx - r * 0.2f, cy + r, fill)
                    c.drawRect(cx + r * 0.2f, cy - r, cx + r * 0.75f, cy + r, fill)
                }
                K.BACK, K.FWD -> {
                    val fwd = kind == K.FWD
                    box.set(cx - r, cy - r, cx + r, cy + r)
                    if (fwd) c.drawArc(box, -60f, 300f, false, line) else c.drawArc(box, -120f, -300f, false, line)
                    val endDeg = if (fwd) 240.0 else -60.0
                    val th = Math.toRadians(endDeg)
                    val px = (cx + r * Math.cos(th)).toFloat()
                    val py = (cy + r * Math.sin(th)).toFloat()
                    val sign = if (fwd) 1.0 else -1.0
                    val tx = (-Math.sin(th) * sign).toFloat()
                    val ty = (Math.cos(th) * sign).toFloat()
                    val nx = Math.cos(th).toFloat()
                    val ny = Math.sin(th).toFloat()
                    path.reset()
                    path.moveTo(px + tx * r * 0.6f, py + ty * r * 0.6f)
                    path.lineTo(px + nx * r * 0.4f, py + ny * r * 0.4f)
                    path.lineTo(px - nx * r * 0.4f, py - ny * r * 0.4f)
                    path.close()
                    c.drawPath(path, fill)
                    fill.textSize = r * 0.95f
                    c.drawText("10", cx, cy + r * 0.33f, fill)
                }
                K.VOL, K.MUTE -> {
                    path.reset()
                    path.moveTo(cx - r, cy - r * 0.4f)
                    path.lineTo(cx - r * 0.4f, cy - r * 0.4f)
                    path.lineTo(cx + r * 0.2f, cy - r * 0.9f)
                    path.lineTo(cx + r * 0.2f, cy + r * 0.9f)
                    path.lineTo(cx - r * 0.4f, cy + r * 0.4f)
                    path.lineTo(cx - r, cy + r * 0.4f)
                    path.close()
                    c.drawPath(path, fill)
                    if (kind == K.VOL) {
                        box.set(cx + r * 0.2f - r * 0.45f, cy - r * 0.45f, cx + r * 0.2f + r * 0.45f, cy + r * 0.45f)
                        c.drawArc(box, -50f, 100f, false, line)
                        box.set(cx + r * 0.2f - r * 0.9f, cy - r * 0.9f, cx + r * 0.2f + r * 0.9f, cy + r * 0.9f)
                        c.drawArc(box, -50f, 100f, false, line)
                    } else {
                        c.drawLine(cx + r * 0.5f, cy - r * 0.4f, cx + r * 1.1f, cy + r * 0.4f, line)
                        c.drawLine(cx + r * 0.5f, cy + r * 0.4f, cx + r * 1.1f, cy - r * 0.4f, line)
                    }
                }
                K.MINUS -> c.drawLine(cx - r * 0.8f, cy, cx + r * 0.8f, cy, line)
                K.PLUS -> {
                    c.drawLine(cx - r * 0.8f, cy, cx + r * 0.8f, cy, line)
                    c.drawLine(cx, cy - r * 0.8f, cx, cy + r * 0.8f, line)
                }
                K.FULL -> {
                    val a = r * 0.6f
                    corner(c, cx - r, cy - r, 1f, 1f, a)
                    corner(c, cx + r, cy - r, -1f, 1f, a)
                    corner(c, cx - r, cy + r, 1f, -1f, a)
                    corner(c, cx + r, cy + r, -1f, -1f, a)
                }
                K.EXIT -> {
                    val a = r * 0.6f
                    val o = r * 0.4f
                    corner(c, cx - o, cy - o, -1f, -1f, a)
                    corner(c, cx + o, cy - o, 1f, -1f, a)
                    corner(c, cx - o, cy + o, -1f, 1f, a)
                    corner(c, cx + o, cy + o, 1f, 1f, a)
                }
                K.CLOSE -> {
                    c.drawLine(cx - r * 0.75f, cy - r * 0.75f, cx + r * 0.75f, cy + r * 0.75f, line)
                    c.drawLine(cx - r * 0.75f, cy + r * 0.75f, cx + r * 0.75f, cy - r * 0.75f, line)
                }
            }
        }
    }
}
