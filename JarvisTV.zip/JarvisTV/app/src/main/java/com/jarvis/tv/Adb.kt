package com.jarvis.tv

import dadb.AdbKeyPair
import dadb.AdbShellPacket
import dadb.Dadb
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * The TV's own adbd, reached over 127.0.0.1:5555.
 *
 * It is what lets Mark LVII press keys, tap, type and take screenshots inside
 * other apps — things Android never gives an ordinary app. One-time setup on
 * the TV: Developer options -> USB debugging on and network debugging on, then
 * accept the "Allow debugging?" prompt (tick "always allow").
 */
object Adb {
    private val lock = Any()
    private var conn: Dadb? = null
    private val hosts = arrayOf("127.0.0.1")
    private const val PORT = 5555

    private fun keyPair(): AdbKeyPair {
        val dir = File(Bridge.app.filesDir, "adb").apply { mkdirs() }
        val priv = File(dir, "adbkey")
        val pub = File(dir, "adbkey.pub")
        if (!priv.exists() || !pub.exists()) AdbKeyPair.generate(priv, pub)
        return AdbKeyPair.read(priv, pub)
    }

    private fun connect(): Dadb {
        synchronized(lock) {
            conn?.let { return it }
            var last: Throwable? = null
            for (h in hosts) {
                try {
                    val d = Dadb.create(h, PORT, keyPair())
                    d.shell("echo ok")           // forces the auth handshake now
                    conn = d
                    return d
                } catch (t: Throwable) { last = t }
            }
            throw IllegalStateException("adbd is not reachable on 127.0.0.1:$PORT (${last?.message})")
        }
    }

    private fun drop() { synchronized(lock) { try { conn?.close() } catch (_: Throwable) {}; conn = null } }

    fun available(): Boolean = try { connect().shell("echo ok").output.trim() == "ok" } catch (_: Throwable) { drop(); false }

    /** stdout of a shell command. Throws if adbd is not reachable. */
    fun shell(cmd: String): String {
        try {
            val r = connect().shell(cmd)
            if (r.exitCode != 0 && r.output.isBlank()) {
                throw IllegalStateException(r.errorOutput.ifBlank { "exit ${r.exitCode}" })
            }
            return r.output
        } catch (t: IllegalStateException) {
            throw t
        } catch (t: Throwable) {
            drop()
            throw IllegalStateException(t.message ?: t.javaClass.simpleName)
        }
    }

    /** PNG bytes of the whole screen. Binary-safe (shell v2 stream). */
    fun screencap(): ByteArray {
        try {
            val out = ByteArrayOutputStream()
            connect().openShell("screencap -p").use { stream ->
                while (true) {
                    val p = stream.read()
                    if (p is AdbShellPacket.StdOut) out.write(p.payload)
                    else if (p is AdbShellPacket.Exit) break
                }
            }
            return out.toByteArray()
        } catch (t: Throwable) {
            drop()
            throw IllegalStateException(t.message ?: t.javaClass.simpleName)
        }
    }
}
