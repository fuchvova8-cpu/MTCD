package com.jarvis.tv

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Everything that could explain a microphone / session drop, in one timestamped file:
 * `Jarvis/diag.log` (previous run: `diag.old.log`). Clock = same as jarvis.log (HH:mm:ss).
 *
 * Tags: BOOT device+app facts · MIC capture life-cycle and 5 s heartbeat · SPK playback ·
 * STATE Jarvis state changes · CHAT every message shown on the HUD · SYS system broadcasts
 * (screen, screensaver, mic mute, headset, BT) · DEV audio devices plugged/unplugged ·
 * NET network up/down · MEM memory pressure · CRASH uncaught exceptions.
 */
object Diag {
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    @Volatile private var inited = false

    private fun file(): File? = try {
        File(AssetInstaller.targetDir(Bridge.app), "diag.log")
    } catch (_: Throwable) { null }

    @Synchronized fun log(tag: String, msg: String) {
        try {
            val f = file() ?: return
            if (f.length() > 1_500_000) {
                val old = File(f.parentFile, "diag.old.log")
                old.delete(); f.renameTo(old)
            }
            f.appendText(fmt.format(Date()) + " [" + tag + "] " + msg.take(400).replace('\n', ' ') + "\n")
        } catch (_: Throwable) {}
    }

    private fun am(): AudioManager = Bridge.app.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun typeName(t: Int): String = when (t) {
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "builtin_mic"
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "builtin_speaker"
        AudioDeviceInfo.TYPE_HDMI -> "hdmi"
        AudioDeviceInfo.TYPE_HDMI_ARC -> "hdmi_arc"
        AudioDeviceInfo.TYPE_USB_DEVICE -> "usb_device"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "usb_headset"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "bt_sco"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "bt_a2dp"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "wired_headset"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "wired_headphones"
        AudioDeviceInfo.TYPE_REMOTE_SUBMIX -> "remote_submix"
        AudioDeviceInfo.TYPE_TELEPHONY -> "telephony"
        else -> "type$t"
    }

    private fun dev(d: AudioDeviceInfo) =
        typeName(d.type) + (if (d.isSource) "(in)" else "") + (if (d.isSink) "(out)" else "") + ":" + d.productName

    /** Short picture of the audio/system state, used on every event and every 30 s. */
    fun snapshot(): String = try {
        val a = am()
        val cfgs = a.activeRecordingConfigurations
        val mi = ActivityManager.MemoryInfo()
        (Bridge.app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val load = try { File("/proc/loadavg").readText().split(" ").take(3).joinToString("/") } catch (_: Throwable) { "?" }
        "state=${Bridge.curState} micFree=${Bridge.micFree}(paused=${Bridge.micPaused},visible=${Bridge.appVisible},mode=${MicMode.label()}) " +
            "mode=${a.mode} micMute=${a.isMicrophoneMute} spk=${a.isSpeakerphoneOn} sco=${a.isBluetoothScoOn} " +
            "vol=${a.getStreamVolume(AudioManager.STREAM_MUSIC)}/${a.getStreamMaxVolume(AudioManager.STREAM_MUSIC)} " +
            "captures=${cfgs.size}" + cfgs.joinToString(prefix = "[", postfix = "]") { "src${it.clientAudioSource}/s${it.clientAudioSessionId}" } +
            " mem=${mi.availMem / 1048576}MB/${mi.totalMem / 1048576}MB low=${mi.lowMemory} load=$load"
    } catch (t: Throwable) { "snapshot failed: ${t.javaClass.simpleName}" }

    fun init(app: android.app.Application) {
        if (inited) return
        inited = true
        val main = Handler(Looper.getMainLooper())
        try {
            val pi = app.packageManager.getPackageInfo(app.packageName, 0)
            val ci = ActivityManager.MemoryInfo()
            (app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(ci)
            log("BOOT", "=== process ${Process.myPid()} started; app ${pi.versionName}(${pi.versionCode}); " +
                "${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE}, ${Build.HARDWARE}); Android ${Build.VERSION.RELEASE}/SDK ${Build.VERSION.SDK_INT}; " +
                "ABI ${Build.SUPPORTED_ABIS.joinToString(",")}; RAM ${ci.totalMem / 1048576} MB; build ${Build.DISPLAY}")
            log("BOOT", "audio devices: " + am().getDevices(AudioManager.GET_DEVICES_ALL).joinToString("; ") { dev(it) })
            log("BOOT", snapshot())
        } catch (t: Throwable) { log("BOOT", "init failed: $t") }

        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { th, e ->
            log("CRASH", "thread ${th.name}: ${android.util.Log.getStackTraceString(e)}")
            prev?.uncaughtException(th, e)
        }

        try {
            am().registerAudioDeviceCallback(object : AudioDeviceCallback() {
                override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>) {
                    log("DEV", "added: " + added.joinToString("; ") { dev(it) })
                }
                override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>) {
                    log("DEV", "removed: " + removed.joinToString("; ") { dev(it) })
                }
            }, main)
        } catch (_: Throwable) {}

        try {
            am().registerAudioRecordingCallback(object : AudioManager.AudioRecordingCallback() {
                override fun onRecordingConfigChanged(configs: MutableList<android.media.AudioRecordingConfiguration>) {
                    log("MIC", "system captures changed -> ${configs.size}" + configs.joinToString(prefix = " [", postfix = "]") {
                        "src${it.clientAudioSource}/s${it.clientAudioSessionId}"
                    } + " state=${Bridge.curState}")
                }
            }, main)
        } catch (_: Throwable) {}

        try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(n: Network) {
                    val c = cm.getNetworkCapabilities(n)
                    val kind = when {
                        c == null -> "?"
                        c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                        c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
                        else -> "other"
                    }
                    log("NET", "available ($kind)")
                }
                override fun onLost(n: Network) { log("NET", "LOST") }
            }, main)
        } catch (_: Throwable) {}

        try {
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_DREAMING_STARTED); addAction(Intent.ACTION_DREAMING_STOPPED)
                addAction(AudioManager.ACTION_MICROPHONE_MUTE_CHANGED)
                addAction(AudioManager.ACTION_SPEAKERPHONE_STATE_CHANGED)
                addAction(AudioManager.ACTION_HEADSET_PLUG)
                addAction(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
                addAction(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED)
                addAction("android.bluetooth.device.action.ACL_CONNECTED")
                addAction("android.bluetooth.device.action.ACL_DISCONNECTED")
                addAction("android.intent.action.CLOSE_SYSTEM_DIALOGS")
            }
            app.registerReceiver(object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    val extra = i.extras?.keySet()?.joinToString(",") { k -> k + "=" + i.extras?.get(k) } ?: ""
                    log("SYS", "broadcast ${i.action} $extra; ${snapshot()}")
                }
            }, f)
        } catch (_: Throwable) {}
    }

    fun memory(level: String) = log("MEM", "$level; ${snapshot()}")

    /** Wall clock helper for heartbeat stamps. */
    fun up(): Long = SystemClock.elapsedRealtime() / 1000
}
