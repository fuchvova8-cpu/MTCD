package com.jarvis.tv

import android.content.Context
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView

/** Number in the corner of a poster: the same plate in the overlay and in the JARVIS results window. */
object Badge {
    /** [sizeSp] is the digit size; the plate grows with it (12 sp = the original 22 dp plate). */
    fun make(ctx: Context, n: Int, fill: Int, ink: Int, sizeSp: Float = 12f): TextView {
        val d = ctx.resources.displayMetrics.density
        val h = (sizeSp * 1.83f * d).toInt()
        return TextView(ctx).apply {
            text = n.toString()
            textSize = sizeSp
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(ink)
            gravity = Gravity.CENTER
            minWidth = h
            setPadding((sizeSp * 0.5f * d).toInt(), 0, (sizeSp * 0.5f * d).toInt(), 0)
            background = Skin.roundRect(ctx, fill, 0, 0f, -1)
        }
    }

    /** [xDp]/[yDp]: where the number sits on the poster (from its top-left corner). */
    fun params(ctx: Context, sizeSp: Float = 12f, xDp: Float = 6f, yDp: Float = 6f): FrameLayout.LayoutParams {
        val d = ctx.resources.displayMetrics.density
        return FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, (sizeSp * 1.83f * d).toInt(), Gravity.TOP or Gravity.START)
            .apply { setMargins((xDp * d).toInt(), (yDp * d).toInt(), 0, 0) }
    }
}

/**
 * Buttons that float over a panel and can be dragged anywhere with the mouse.
 * The position is kept as a fraction (0..1) of the free room inside the panel, so it follows the panel when it
 * grows (results appear) and is saved per [prefix] (one set of positions per screen) in the layout file.
 * A click still works: only a move longer than a few dp drags.
 */
class Floating(private val host: FrameLayout, private val prefix: String) {
    private class Item(val v: View, val defX: (Int, Int) -> Int, val defY: (Int, Int) -> Int)

    private val items = LinkedHashMap<String, Item>()
    private val d = host.resources.displayMetrics.density

    init {
        host.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) place()
        }
    }

    /** [defX]/[defY]: where the button sits until it is moved, in pixels from (panel size, button size). */
    fun add(id: String, v: View, w: Int, h: Int, defX: (Int, Int) -> Int, defY: (Int, Int) -> Int) {
        items[id] = Item(v, defX, defY)
        v.elevation = 20 * d            // above the panel, which has its own shadow height
        host.addView(v, FrameLayout.LayoutParams(w, h, Gravity.TOP or Gravity.START))
        v.setOnTouchListener(dragger(id))
        v.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> place() }
    }

    fun place() {
        if (host.width == 0) return
        for ((id, item) in items) {
            val v = item.v
            if (v.width == 0) continue
            val rx = (host.width - v.width).coerceAtLeast(0).toFloat()
            val ry = (host.height - v.height).coerceAtLeast(0).toFloat()
            val p = Skin.floatPos("$prefix.$id")
            v.translationX = if (p != null) (p[0] * rx).coerceIn(0f, rx) else item.defX(host.width, v.width).toFloat().coerceIn(0f, rx)
            v.translationY = if (p != null) (p[1] * ry).coerceIn(0f, ry) else item.defY(host.height, v.height).toFloat().coerceIn(0f, ry)
        }
    }

    private fun dragger(id: String): View.OnTouchListener {
        var x0 = 0f
        var y0 = 0f
        var tx0 = 0f
        var ty0 = 0f
        var moved = false
        val slop = 8 * d
        return View.OnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    x0 = e.rawX; y0 = e.rawY
                    tx0 = v.translationX; ty0 = v.translationY
                    moved = false
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - x0
                    val dy = e.rawY - y0
                    if (!moved && Math.hypot(dx.toDouble(), dy.toDouble()) > slop) {
                        moved = true
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                        val c = MotionEvent.obtain(e)
                        c.action = MotionEvent.ACTION_CANCEL      // the button must not "click" after a drag
                        v.onTouchEvent(c)
                        c.recycle()
                    }
                    if (moved) {
                        v.translationX = (tx0 + dx).coerceIn(0f, (host.width - v.width).coerceAtLeast(0).toFloat())
                        v.translationY = (ty0 + dy).coerceIn(0f, (host.height - v.height).coerceAtLeast(0).toFloat())
                        true
                    } else false
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        moved = false
                        val rx = (host.width - v.width).coerceAtLeast(1).toFloat()
                        val ry = (host.height - v.height).coerceAtLeast(1).toFloat()
                        Skin.saveFloatPos("$prefix.$id", v.translationX / rx, v.translationY / ry)
                        true
                    } else false
                }
                MotionEvent.ACTION_CANCEL -> { moved = false; false }
                else -> false
            }
        }
    }
}
