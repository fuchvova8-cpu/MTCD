package com.jarvis.tv

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Auto-start with the TV (switch it off in Settings inside the app). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val p = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        if (p.getBoolean("autostart", true)) {
            try { JarvisService.start(context) } catch (_: Throwable) {}
        }
    }
}
