package com.jarvis.tv

/** Same bottom strip, separate launcher entry with its own task (the main window is not brought forward). */
class MicBarActivity : OverlayActivity() {
    /** The strip stays after the answer, so the microphone can be pressed again without calling it up anew. */
    override val stayOpen: Boolean = true

    /** The strip has its own block in the layout file: position, size, microphone, number and buttons. */
    override val section: String get() = "bar"
}
