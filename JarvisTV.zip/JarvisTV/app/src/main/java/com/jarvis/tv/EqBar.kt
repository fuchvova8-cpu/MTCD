package com.jarvis.tv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View

/**
 * One vertical "equalizer" bar (0..255) used to mix a colour: R, G, B and alpha side by side.
 *
 * Mouse / touch: press or drag on the bar sets the level.
 * Remote: OK starts adjusting (the frame turns solid), Up/Down change the level (hold = faster),
 * OK or Back stops adjusting; while not adjusting Up/Down move focus as usual.
 */
class EqBar(
    ctx: Context,
    private val tint: Int,
    value: Int,
    private val onChange: (Int) -> Unit
) : View(ctx) {

    var value: Int = value.coerceIn(0, 255)
        set(v) { field = v.coerceIn(0, 255); invalidate() }

    private var adjusting = false
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val segments = 16

    init {
        isFocusable = true
        isClickable = true
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension((46 * d).toInt(), (150 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = 4 * d
        val gap = 2 * d
        val segH = (h - 2 * pad - gap * (segments - 1)) / segments
        val lit = Math.round(value / 255f * segments)
        for (i in 0 until segments) {
            val top = h - pad - (i + 1) * segH - i * gap
            r.set(pad + 2 * d, top, w - pad - 2 * d, top + segH)
            paint.style = Paint.Style.FILL
            paint.color = if (i < lit) tint else Hud.withAlpha(Color.WHITE, 0x22)
            c.drawRoundRect(r, 3 * d, 3 * d, paint)
        }
        if (isFocused || adjusting) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = if (adjusting) 3 * d else 1.5f * d
            paint.color = if (adjusting) Color.WHITE else Hud.CYAN
            r.set(1.5f * d, 1.5f * d, w - 1.5f * d, h - 1.5f * d)
            c.drawRoundRect(r, 8 * d, 8 * d, paint)
        }
    }

    private fun set(v: Int) {
        val nv = v.coerceIn(0, 255)
        if (nv == value) return
        value = nv
        onChange(nv)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                adjusting = !adjusting
                invalidate()
                return true
            }
            KeyEvent.KEYCODE_BACK -> if (adjusting) {
                adjusting = false
                invalidate()
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP -> if (adjusting) {
                set(value + if (event.repeatCount > 2) 16 else 4)
                return true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> if (adjusting) {
                set(value - if (event.repeatCount > 2) 16 else 4)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: android.graphics.Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        if (!gainFocus) adjusting = false
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val pad = 4 * d
                val f = 1f - ((e.y - pad) / (height - 2 * pad)).coerceIn(0f, 1f)
                set(Math.round(f * 255f))
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}
