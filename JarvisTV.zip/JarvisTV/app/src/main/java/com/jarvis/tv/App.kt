package com.jarvis.tv

import android.app.Application
import android.os.StrictMode

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Bridge.app = this
        Diag.init(this)
        MicMode.load()
        // The original hands plain file paths to players/browsers (file:// URIs).
        StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().build())
    }

    override fun onTrimMemory(level: Int) { super.onTrimMemory(level); Diag.memory("trimMemory level=$level") }
    override fun onLowMemory() { super.onLowMemory(); Diag.memory("LOW MEMORY") }
}
