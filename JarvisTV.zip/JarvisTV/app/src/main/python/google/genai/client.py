"""Client: REST generate_content and the Live WebSocket session."""
from __future__ import annotations

import asyncio
import json

from . import errors
from .types import (Content, GenerateContentResponse, LiveServerMessage, Part, _Obj,
                    from_wire, to_wire)

_HOST = "generativelanguage.googleapis.com"


def _opt(http_options, name, default=None):
    if http_options is None:
        return default
    if isinstance(http_options, dict):
        v = http_options.get(name)
    else:
        v = getattr(http_options, name, None)
    return default if v is None else v


# ── contents / config normalisation ─────────────────────────────────────────
def _is_part_like(x) -> bool:
    if isinstance(x, (str, Part)):
        return True
    if isinstance(x, dict):
        return "parts" not in x
    return isinstance(x, _Obj) and not isinstance(x, Content)


def _part(x):
    if isinstance(x, str):
        return {"text": x}
    return to_wire(x)


def _content(x, default_role="user"):
    if isinstance(x, Content) or (isinstance(x, dict) and "parts" in x):
        w = to_wire(x)
        w.setdefault("role", default_role)
        return w
    return {"role": default_role, "parts": [_part(x)]}


def contents_to_wire(contents):
    if isinstance(contents, (list, tuple)):
        if contents and all(not _is_part_like(c) for c in contents):
            return [_content(c) for c in contents]
        return [{"role": "user", "parts": [_part(c) for c in contents]}]
    return [_content(contents)]


def _cfg_get(cfg, name):
    if isinstance(cfg, dict):
        return cfg.get(name)
    return getattr(cfg, name, None)


def _cfg_items(cfg):
    if cfg is None:
        return {}
    if isinstance(cfg, dict):
        return {k: v for k, v in cfg.items() if v is not None}
    return {k: v for k, v in vars(cfg).items() if v is not None and not k.startswith("_")}


def _instruction(si):
    if si is None:
        return None
    if isinstance(si, str):
        return {"parts": [{"text": si}]}
    if isinstance(si, (list, tuple)):
        return {"parts": [_part(p) for p in si]}
    w = to_wire(si)
    return w if "parts" in w else {"parts": [w]}


_TOP_REST = {"tools", "tool_config", "safety_settings", "cached_content"}
_SKIP_REST = {"automatic_function_calling", "http_options", "system_instruction"}


def rest_body(contents, config) -> dict:
    body = {"contents": contents_to_wire(contents)}
    gen: dict = {}
    for k, v in _cfg_items(config).items():
        if k in _SKIP_REST:
            continue
        if k in _TOP_REST:
            body[k if "_" not in k else _camel(k)] = to_wire(v)
        else:
            gen[_camel(k)] = to_wire(v)
    si = _instruction(_cfg_get(config, "system_instruction"))
    if si:
        body["systemInstruction"] = si
    if gen:
        body["generationConfig"] = gen
    return body


def _camel(k):
    from .types import camel
    return camel(k)


_SETUP_GEN = {"response_modalities", "speech_config", "media_resolution", "thinking_config",
              "temperature", "top_p", "top_k", "max_output_tokens", "seed",
              "enable_affective_dialog"}


def live_setup(model: str, config) -> dict:
    setup: dict = {"model": model if "/" in model else f"models/{model}"}
    gen: dict = {}
    for k, v in _cfg_items(config).items():
        if k == "system_instruction":
            continue
        if k in _SETUP_GEN:
            gen[_camel(k)] = to_wire(v)
        else:
            setup[_camel(k)] = to_wire(v)
    si = _instruction(_cfg_get(config, "system_instruction"))
    if si:
        setup["systemInstruction"] = si
    if gen:
        setup["generationConfig"] = gen
    return {"setup": setup}


# ── REST ────────────────────────────────────────────────────────────────────
class Models:
    def __init__(self, client):
        self._c = client

    def generate_content(self, *, model, contents, config=None):
        import requests

        mdl = model if "/" in model else f"models/{model}"
        url = f"https://{_HOST}/{self._c.api_version}/{mdl}:generateContent"
        body = rest_body(contents, config)
        timeout = max(1.0, self._c.timeout_ms / 1000.0)
        try:
            r = requests.post(url, json=body, timeout=(min(15.0, timeout), timeout),
                              headers={"x-goog-api-key": self._c.api_key,
                                       "Content-Type": "application/json"})
        except requests.exceptions.Timeout as e:
            raise errors.ServerError(504, {"error": {"status": "DEADLINE_EXCEEDED",
                                                     "message": f"timeout: {e}"}})
        if r.status_code >= 400:
            try:
                j = r.json()
            except Exception:
                j = {"error": {"message": r.text[:500]}}
            if isinstance(j, list) and j:
                j = j[0]
            cls = errors.ClientError if r.status_code < 500 else errors.ServerError
            raise cls(r.status_code, j)
        data = r.json()
        resp = from_wire(data)
        out = GenerateContentResponse(**vars(resp))
        return out


# ── Live ────────────────────────────────────────────────────────────────────
class AsyncSession:
    def __init__(self, ws):
        self._ws = ws

    async def _send(self, obj):
        await self._ws.send(json.dumps(obj))

    async def send_realtime_input(self, *, audio=None, video=None, text=None, media=None,
                                  audio_stream_end=None, activity_start=None, activity_end=None):
        msg: dict = {}
        if audio is not None:
            msg["audio"] = to_wire(audio)
        if video is not None:
            msg["video"] = to_wire(video)
        if media is not None:
            msg["mediaChunks"] = [to_wire(media)]
        if text is not None:
            msg["text"] = text
        if audio_stream_end:
            msg["audioStreamEnd"] = True
        if activity_start is not None:
            msg["activityStart"] = {}
        if activity_end is not None:
            msg["activityEnd"] = {}
        await self._send({"realtimeInput": msg})

    async def send_client_content(self, *, turns=None, turn_complete=True):
        msg: dict = {}
        if turns is not None:
            lst = turns if isinstance(turns, (list, tuple)) else [turns]
            msg["turns"] = [_content(t) for t in lst]
        msg["turnComplete"] = bool(turn_complete)
        await self._send({"clientContent": msg})

    async def send_tool_response(self, *, function_responses):
        lst = function_responses if isinstance(function_responses, (list, tuple)) \
            else [function_responses]
        await self._send({"toolResponse": {"functionResponses": [to_wire(f) for f in lst]}})

    async def receive(self):
        """Yield messages until the model's turn is complete (as the SDK does)."""
        while True:
            raw = await self._ws.recv()
            if isinstance(raw, (bytes, bytearray)):
                raw = bytes(raw).decode("utf-8", "replace")
            msg = from_wire(json.loads(raw))
            m = LiveServerMessage(**vars(msg))
            yield m
            sc = m.server_content
            if sc is not None and getattr(sc, "turn_complete", None):
                return

    async def close(self):
        await self._ws.close()


class _LiveConnect:
    def __init__(self, client, model, config):
        self._c, self._model, self._config = client, model, config
        self._ws = None

    async def __aenter__(self):
        import websockets

        uri = (f"wss://{_HOST}/ws/google.ai.generativelanguage."
               f"{self._c.api_version}.GenerativeService.BidiGenerateContent")
        headers = {"x-goog-api-key": self._c.api_key}
        try:
            self._ws = await websockets.connect(uri, additional_headers=headers,
                                                max_size=None, ping_interval=20, ping_timeout=20)
        except TypeError:                              # old websockets
            self._ws = await websockets.connect(uri, extra_headers=headers, max_size=None)
        try:
            await self._ws.send(json.dumps(live_setup(self._model, self._config)))
            raw = await self._ws.recv()
            if isinstance(raw, (bytes, bytearray)):
                raw = bytes(raw).decode("utf-8", "replace")
            first = json.loads(raw)
            if "setupComplete" not in first:
                raise errors.APIError(500, {"error": {"message": f"unexpected setup reply: {raw[:300]}"}})
        except BaseException:
            await self._safe_close()
            raise
        return AsyncSession(self._ws)

    async def _safe_close(self):
        try:
            if self._ws is not None:
                await self._ws.close()
        except Exception:
            pass

    async def __aexit__(self, *exc):
        await self._safe_close()
        return False


class _Live:
    def __init__(self, client):
        self._c = client

    def connect(self, *, model, config=None):
        return _LiveConnect(self._c, model, config)


class _Aio:
    def __init__(self, client):
        self.live = _Live(client)


class Client:
    def __init__(self, *, api_key=None, http_options=None, **_):
        self.api_key = api_key
        self.api_version = _opt(http_options, "api_version", "v1beta")
        self.timeout_ms = int(_opt(http_options, "timeout", 600_000))
        self.models = Models(self)
        self.aio = _Aio(self)

    def close(self):
        pass
