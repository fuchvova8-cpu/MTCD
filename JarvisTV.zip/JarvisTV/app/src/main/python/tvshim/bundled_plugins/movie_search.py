"""Поиск фильмов и сериалов в видеосервисах ТВ (Lazy Media Deluxe, Zona, HDRezka и др.).

Приложение опрашивает поисковые провайдеры установленных программ (как системный поиск
Android TV, без root) и показывает результаты плитками на экране JARVIS. Выбор — пультом или
мышью, либо голосом: «открой номер 3».

Какие сервисы опрашивать — Меню → Настройки плагинов → «Поиск фильмов».
"""
import json
import os
import threading

import android_bridge as android

PLUGIN = {
    "name": "movie_search",
    "description": (
        "Найти фильм, сериал или видео в видеосервисах на ТВ (Lazy Media Deluxe, Zona, HDRezka и др.) "
        "и показать результаты плитками на экране. Вызывай на «найди фильм…», «поищи сериал…», "
        "«есть ли в зоне…». Чтобы открыть один из показанных результатов, вызови с open_number "
        "(«открой номер 3», «включи второй»)."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "query": {"type": "STRING", "description": "Что искать: название фильма или сериала"},
            "service": {"type": "STRING", "description": "Необязательно: только в этом сервисе (например «зона», «lazy», «rezka»)"},
            "open_number": {"type": "INTEGER", "description": "Открыть результат с этим номером из последнего показа"},
        },
    },
}

SETTINGS = {"title": "Поиск фильмов"}

DEFAULT_SERVICES = "lazy\nzona\nзона\nrezka\nрезка\nkinopub\nlampa\nvimu\nivi\nokko\nkion\nwink"
_SKIP_PKG = ("com.google.", "com.android.", "android", "com.mitv", "com.xiaomi", "com.mi.")
_last = []          # items of the last show, for "открой номер N"
_lock = threading.Lock()


# ── config ──────────────────────────────────────────────────────────────────
def _file():
    return os.path.join(android.data_dir() or ".", "movie_search.json")


def _cfg():
    try:
        with open(_file(), encoding="utf-8") as f:
            c = json.load(f)
    except Exception:
        c = {}
    c.setdefault("services", DEFAULT_SERVICES)
    c.setdefault("all_tv", False)
    return c


def _save(c):
    try:
        with open(_file(), "w", encoding="utf-8") as f:
            json.dump(c, f, ensure_ascii=False, indent=1)
    except Exception as e:
        android.log("movie_search: не сохранить: %s" % e)


def _keywords(c):
    return [x.strip().lower() for x in str(c.get("services", "")).splitlines() if x.strip()]


# ── providers ───────────────────────────────────────────────────────────────
def _providers(service=""):
    """[(authority, pkg, label)] to ask. None = this build can't list providers."""
    provs = android.provider_list()
    if provs is None:
        return None
    labels = {}
    tv = set()
    for a in (android.list_apps() or []):
        labels[a.get("pkg")] = a.get("label", "")
        if a.get("tv"):
            tv.add(a.get("pkg"))
    c = _cfg()
    words = [service.strip().lower()] if service.strip() else _keywords(c)
    out, seen = [], set()
    for auth, pkg in provs:
        label = labels.get(pkg, "")
        hay = ("%s %s %s" % (pkg, label, auth)).lower()
        if any(w and w in hay for w in words):
            out.append((auth, pkg, label or pkg))
            seen.add(auth)
    if not out and (c.get("all_tv") or service.strip()):
        for auth, pkg in provs:
            if pkg in tv and not pkg.startswith(_SKIP_PKG) and auth not in seen:
                out.append((auth, pkg, labels.get(pkg) or pkg))
    return out


def _g(row, *keys):
    for k in keys:
        v = row.get(k)
        if v and str(v).strip() and str(v).strip().lower() != "null":
            return str(v).strip()
    return ""


def _q(s):
    return "'" + str(s).replace("'", "'\\''") + "'"


def _item(row, pkg, label):
    title = _g(row, "suggest_text_1", "text1")
    if not title:
        return None
    image = _g(row, "suggest_result_card_image", "suggest_icon_1", "icon1")
    if not image.startswith(("http://", "https://", "content://", "file://")):
        image = ""
    action = _g(row, "suggest_intent_action", "_default_action") or "android.intent.action.VIEW"
    data = _g(row, "suggest_intent_data", "_default_data")
    did = _g(row, "suggest_intent_data_id")
    if data and did:
        data = data.rstrip("/") + "/" + did
    comp = _g(row, "_component")
    extras = {}
    if _g(row, "suggest_intent_extra_data"):
        extras["intent_extra_data_key"] = _g(row, "suggest_intent_extra_data")
    if _g(row, "suggest_intent_query"):
        extras["query"] = _g(row, "suggest_intent_query")
    intents = []
    if comp:
        intents.append({"name": "component", "action": action, "data": data, "comp": comp, "extras": extras})
    intents.append({"name": "package", "action": action, "data": data, "pkg": pkg, "extras": extras})
    if data:
        intents.append({"name": "view", "action": "android.intent.action.VIEW", "data": data, "pkg": pkg})
    cmds = []
    if data:
        cmds.append("am start -a %s -d %s -p %s" % (_q(action), _q(data), _q(pkg)))
        cmds.append("am start -a android.intent.action.VIEW -d %s" % _q(data))
    return {"title": title, "sub": _g(row, "suggest_text_2", "text2"), "image": image,
            "year": _g(row, "suggest_production_year"), "app": label,
            "intents": intents, "cmds": cmds}


def _ask(auth, pkg, label, query, out, errs):
    rows, err = android.provider_query(auth, query, 20)
    if rows is None:
        errs.append("%s: %s" % (label, (err or "")[:80]))
        return
    for r in rows:
        it = _item(r, pkg, label)
        if it:
            out.append(it)


# ── tool ────────────────────────────────────────────────────────────────────
def _open(n):
    with _lock:
        items = list(_last)
    if not items:
        return "Сначала найдите фильм — результатов на экране нет."
    if n < 1 or n > len(items):
        return "Есть номера с 1 по %d." % len(items)
    it = items[n - 1]
    res = android.open_intents(it["title"], it["intents"]) or "ERR: нет связи"
    if res.startswith("ERR"):
        for c in it.get("cmds", []):
            out = android.shell(c)
            low = str(out).lower()
            if not (low.startswith("adb:") or "error" in low or "exception" in low or "unable to resolve" in low):
                res = "ok:shell"
                break
    if res.startswith("ok"):
        return "Открываю «%s» в %s." % (it["title"], it["app"])
    return "Не открылось «%s»: %s" % (it["title"], res[:120])


def run(parameters, player=None, session_memory=None):
    try:
        n = int(parameters.get("open_number") or 0)
    except (TypeError, ValueError):
        n = 0
    if n:
        return _open(n)
    query = str(parameters.get("query", "")).strip()
    if not query:
        return "Что искать? Назовите фильм или сериал."
    if not android.in_app_search():
        return "Эта сборка не умеет искать в приложениях."
    provs = _providers(str(parameters.get("service", "")))
    if provs is None:
        return "Не удалось получить список поисковых провайдеров."
    if not provs:
        return ("Не нашёл установленных видеосервисов с поиском (Lazy Media Deluxe, Zona и др.). "
                "Установите их или добавьте название в Меню → Настройки плагинов → Поиск фильмов.")
    out, errs, threads = [], [], []
    for auth, pkg, label in provs:
        t = threading.Thread(target=_ask, args=(auth, pkg, label, query, out, errs), daemon=True)
        t.start()
        threads.append(t)
    for t in threads:
        t.join(10)
    seen, items = set(), []
    for it in list(out):
        k = (it["app"], it["title"].lower(), it["sub"].lower())
        if k not in seen:
            seen.add(k)
            items.append(it)
    items = items[:48]
    if not items:
        tail = (" Ошибки: " + "; ".join(errs[:3])) if errs else ""
        return "По запросу «%s» ничего не нашлось (опрошено: %s).%s" % (
            query, ", ".join(sorted({p[2] for p in provs})), tail)
    with _lock:
        _last[:] = items
    android.show_results("Поиск: " + query, items)
    per = {}
    for it in items:
        per[it["app"]] = per.get(it["app"], 0) + 1
    head = "; ".join("%d. %s%s" % (i + 1, it["title"], " (%s)" % it["year"] if it["year"] else "")
                     for i, it in enumerate(items[:5]))
    return ("Показал на экране %d результатов (%s). Первые: %s. Скажи пользователю кратко и "
            "предложи открыть по номеру." % (len(items), ", ".join("%s — %d" % kv for kv in per.items()), head))


# ── settings page ───────────────────────────────────────────────────────────
def settings_items():
    c = _cfg()
    return [
        {"type": "label", "text": "Опрашиваются установленные приложения, в названии/пакете которых есть любое из слов ниже (по одному на строку)."},
        {"type": "text", "id": "services", "label": "Сервисы (ключевые слова)", "value": c["services"],
         "hint": "lazy, zona, rezka…", "multiline": True},
        {"type": "button", "id": "all_tv", "label": "Если не нашлись — искать во всех ТВ-приложениях: " + ("ВКЛ" if c["all_tv"] else "ВЫКЛ")},
        {"type": "button", "id": "scan", "label": "Показать, какие провайдеры найдены сейчас"},
        {"type": "button", "id": "save", "label": "Сохранить"},
    ]


def settings_event(event, values):
    c = _cfg()
    if "services" in (values or {}):
        c["services"] = str(values["services"])
    if event == "all_tv":
        c["all_tv"] = not c["all_tv"]
        _save(c)
        return {"message": "Поиск по всем ТВ-приложениям: " + ("вкл" if c["all_tv"] else "выкл"), "refresh": True}
    _save(c)
    if event == "scan":
        provs = _providers("")
        if provs is None:
            return {"message": "Не удалось получить провайдеры.", "refresh": False}
        names = sorted({p[2] for p in provs})
        return {"message": ("Будут опрошены: " + ", ".join(names)) if names else "Подходящих приложений не найдено.",
                "refresh": False}
    if event == "__leave__":
        return None
    return {"message": "Сохранено", "refresh": False}
