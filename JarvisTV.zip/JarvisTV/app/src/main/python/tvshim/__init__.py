"""tvshim — the Android TV layer under Mark LVII.

Mark LVII itself is shipped unchanged (app/src/main/assets/jarvis). Everything in
this package exists so that code written for a PC finds, on an Android TV, the
same names it always imported:

    sounddevice, mss, pyautogui, pyperclip, psutil   -> top-level modules beside this package
    ui.JarvisUI                                      -> tvshim.ui_android
    pactl / xdotool / xdg-open / notify-send / ...   -> tvshim.toolbox (virtual commands)

Nothing here edits, patches on disk, or re-implements a line of the original.
"""
