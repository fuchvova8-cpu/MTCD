"""Virtual command-line tools.

Mark LVII drives a Linux desktop by running small programs: `pactl` for volume,
`xdotool` for typing, `xdg-open` for links, `notify-send` for notices,
`playerctl` for media keys, `systemd-run` for reminders, `espeak-ng` for the
offline voice. None of them exist on Android.

Rather than touch the original, this module makes them exist as far as Python
can tell: `shutil.which()` finds them, and `subprocess` runs them — in-process,
as calls into Android. Everything else goes to the real subprocess untouched.
A tool that has no Android meaning (brightnessctl, xrandr, wmctrl...) is simply
not offered, so the original's own "not installed" branch reports it honestly.
"""
from __future__ import annotations

import io
import json
import os
import re
import shlex
import shutil
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path

from tvshim import adbio
from tvshim.bridge import kt

VIRTUAL_DIR = "/system/tvshim/bin"

Result = tuple  # (returncode, stdout:str, stderr:str)


# ── pactl: volume and mute through AudioManager ──────────────────────────────
def _pactl(args: list[str], _input) -> Result:
    if not args:
        return 1, "", "pactl: no command"
    cmd = args[0]
    if cmd == "set-sink-volume" and len(args) >= 3:
        spec = args[2]
        m = re.fullmatch(r"([+-]?)(\d+)%?", spec)
        if not m:
            return 1, "", f"pactl: bad volume {spec!r}"
        n = int(m.group(2))
        cur = int(kt().volumeGet())
        new = cur + n if m.group(1) == "+" else cur - n if m.group(1) == "-" else n
        kt().volumeSet(max(0, min(100, new)))
        return 0, "", ""
    if cmd == "get-sink-volume":
        v = int(kt().volumeGet())
        return 0, f"Volume: front-left: {v * 655} / {v}% / 0.00 dB,   front-right: {v * 655} / {v}% / 0.00 dB\n", ""
    if cmd == "set-sink-mute" and len(args) >= 3:
        flag = args[2].lower()
        if flag == "toggle":
            kt().muteSet(not bool(kt().muteGet()))
        else:
            kt().muteSet(flag in ("1", "true", "yes", "on"))
        return 0, "", ""
    if cmd == "get-sink-mute":
        return 0, "Mute: " + ("yes" if kt().muteGet() else "no") + "\n", ""
    return 1, "", f"pactl: unsupported command {cmd}"


# ── xdotool: typing and keys through ADB ─────────────────────────────────────
def _xdotool(args: list[str], _input) -> Result:
    if not args:
        return 1, "", "xdotool: no command"
    cmd, rest = args[0], args[1:]
    try:
        if cmd == "type":
            if "--" in rest:
                rest = rest[rest.index("--") + 1:]
            else:  # drop option flags and their values
                clean, skip = [], False
                for a in rest:
                    if skip:
                        skip = False
                    elif a in ("--delay", "--window"):
                        skip = True
                    elif not a.startswith("--"):
                        clean.append(a)
                rest = clean
            adbio.type_text(" ".join(rest))
            return 0, "", ""
        if cmd == "key":
            keys = [a for a in rest if not a.startswith("--")]
            for k in keys:
                parts = [p for p in k.replace("super", "win").lower().split("+") if p]
                if not adbio.chord(parts):
                    return 1, "", f"xdotool: no Android key for {k!r}"
            return 0, "", ""
        if cmd == "click":
            w, h = adbio.screen_size()
            adbio.tap(w // 2, h // 2)
            return 0, "", ""
        if cmd in ("mousemove",):
            return 0, "", ""
        if cmd == "getactivewindow" or cmd == "getwindowfocus":
            return 0, "1\n", ""
        if cmd == "getwindowname":
            return 0, "Android TV\n", ""
    except adbio.AdbUnavailable as e:
        return 1, "", str(e)
    return 1, "", f"xdotool: {cmd} is not available on Android TV (no window manager)"


# ── xdg-open / gtk-launch / notify-send / playerctl ──────────────────────────
def _xdg_open(args: list[str], _input) -> Result:
    target = next((a for a in args if not a.startswith("-")), "")
    if not target:
        return 1, "", "xdg-open: no target"
    ok = bool(kt().openUrl(target))
    return (0, "", "") if ok else (3, "", f"xdg-open: nothing can open {target}")


def _gtk_launch(args: list[str], _input) -> Result:
    name = next((a for a in args if not a.startswith("-")), "")
    ok = bool(name) and bool(kt().launchApp(name))
    return (0, "", "") if ok else (1, "", f"gtk-launch: no app named {name}")


def _notify_send(args: list[str], _input) -> Result:
    texts = [a for a in args if not a.startswith("-")]
    title = texts[0] if texts else "JARVIS"
    body = texts[1] if len(texts) > 1 else ""
    kt().notify(title, body)
    return 0, "", ""


_MEDIA = {"play-pause": 85, "play": 126, "pause": 127, "next": 87,
          "previous": 88, "stop": 86}


def _playerctl(args: list[str], _input) -> Result:
    code = _MEDIA.get(args[0]) if args else None
    if code is None:
        return 1, "", "playerctl: unsupported command"
    kt().mediaKey(code)
    return 0, "", ""


# ── espeak-ng: Android TextToSpeech writes the .wav ──────────────────────────
def _espeak(args: list[str], _input) -> Result:
    if args and args[0] in ("--voices", "--voices=", "-h", "--version"):
        if args[0] == "--version":
            return 0, "eSpeak NG (Android TextToSpeech bridge)\n", ""
        langs = str(kt().ttsLanguages() or "")
        lines = ["Pty Language       Age/Gender VoiceName          File          Other Languages"]
        for code in filter(None, (s.strip() for s in langs.split(","))):
            lines.append(f" 5  {code:<14} --/M      {code:<18} {code}")
        return 0, "\n".join(lines) + "\n", ""
    voice, rate, wav, text_file, text = "", 0, "", "", []
    it = iter(range(len(args)))
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-v",) and i + 1 < len(args):
            voice = args[i + 1]; i += 2; continue
        if a in ("-s",) and i + 1 < len(args):
            rate = int(args[i + 1]); i += 2; continue
        if a in ("-w",) and i + 1 < len(args):
            wav = args[i + 1]; i += 2; continue
        if a in ("-f",) and i + 1 < len(args):
            text_file = args[i + 1]; i += 2; continue
        if a.startswith("-"):
            i += 1; continue
        text.append(a); i += 1
    body = Path(text_file).read_text(encoding="utf-8") if text_file else " ".join(text)
    if not body.strip():
        return 0, "", ""
    if wav:
        ok = bool(kt().ttsToFile(body, voice, int(rate), wav))
        return (0, "", "") if ok else (1, "", "espeak-ng: Android TextToSpeech could not synthesise")
    ok = bool(kt().tts(body, voice))
    return (0, "", "") if ok else (1, "", "espeak-ng: Android TextToSpeech is not ready")


# ── systemd-run: reminders become persistent in-process jobs ─────────────────
_JOBS_LOCK = threading.Lock()
_timers: dict[str, threading.Timer] = {}


def _jobs_file() -> Path:
    return Path(os.environ.get("JARVIS_HOME", ".")) / "config" / "tvshim_jobs.json"


def _load_jobs() -> dict:
    try:
        return json.loads(_jobs_file().read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_jobs(jobs: dict) -> None:
    try:
        p = _jobs_file()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(jobs, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"[tvshim] jobs not saved: {e}")


def _fire(name: str, script: str) -> None:
    with _JOBS_LOCK:
        jobs = _load_jobs()
        jobs.pop(name, None)
        _save_jobs(jobs)
        _timers.pop(name, None)
    try:
        import runpy
        runpy.run_path(script, run_name="__main__")
    except SystemExit:
        pass
    except Exception as e:
        print(f"[tvshim] reminder script failed: {type(e).__name__}: {e}")


def _arm(name: str, when: float, script: str) -> None:
    delay = max(0.0, when - time.time())
    t = threading.Timer(delay, _fire, args=(name, script))
    t.daemon = True
    with _JOBS_LOCK:
        old = _timers.pop(name, None)
        if old:
            old.cancel()
        _timers[name] = t
    t.start()


def rearm() -> int:
    """Re-create the timers of reminders that were pending at the last shutdown."""
    n = 0
    for name, job in _load_jobs().items():
        script = job.get("script", "")
        if script and os.path.exists(script):
            _arm(name, float(job.get("at", 0)), script)
            n += 1
    return n


def _systemd_run(args: list[str], _input) -> Result:
    cal = next((a.split("=", 1)[1] for a in args if a.startswith("--on-calendar=")), "")
    unit = next((a.split("=", 1)[1] for a in args if a.startswith("--unit=")), f"job_{int(time.time())}")
    if "--" not in args:
        return 1, "", "systemd-run: no command"
    cmd = args[args.index("--") + 1:]
    script = next((c for c in cmd if c.endswith(".py")), "")
    try:
        when = datetime.strptime(cal, "%Y-%m-%d %H:%M:%S").timestamp()
    except ValueError:
        return 1, "", f"systemd-run: cannot read time {cal!r}"
    if not script:
        return 1, "", "systemd-run: only Python reminder scripts are supported here"
    with _JOBS_LOCK:
        jobs = _load_jobs()
        jobs[unit] = {"at": when, "script": script}
        _save_jobs(jobs)
    _arm(unit, when, script)
    return 0, f"Running timer as unit: {unit}.timer\n", ""


_TOOLS = {
    "pactl": _pactl,
    "xdotool": _xdotool,
    "xdg-open": _xdg_open,
    "gtk-launch": _gtk_launch,
    "notify-send": _notify_send,
    "playerctl": _playerctl,
    "systemd-run": _systemd_run,
    "espeak-ng": _espeak,
    "espeak": _espeak,
}


# ── plumbing: shutil.which + subprocess.Popen ────────────────────────────────
_real_which = shutil.which
_RealPopen = subprocess.Popen
_installed = False


def _which(cmd, mode=os.F_OK | os.X_OK, path=None):
    found = _real_which(cmd, mode, path)
    if found:
        return found
    if cmd in _TOOLS:
        return f"{VIRTUAL_DIR}/{cmd}"
    return None


def _virtual_name(args) -> str:
    if isinstance(args, (str, bytes, os.PathLike)):
        return ""                                    # shell strings go to the real thing
    try:
        first = os.fspath(args[0])
    except Exception:
        return ""
    if isinstance(first, bytes):
        first = first.decode("utf-8", "replace")
    base = os.path.basename(first)
    if base in _TOOLS and (first == base or first.startswith(VIRTUAL_DIR)):
        return base
    return ""


class _VirtualPopen:
    """Just enough of subprocess.Popen for run()/check_output()/communicate()."""

    def __init__(self, name, args, stdin=None, stdout=None, stderr=None,
                 text=None, universal_newlines=None, encoding=None, errors=None, **_kw):
        self.args = args
        self.pid = -1
        self.stdin = self.stdout = self.stderr = None
        self.returncode = None
        self._text = bool(text or universal_newlines or encoding or errors)
        self._enc = encoding or "utf-8"
        self._name = name
        self._stdout_mode, self._stderr_mode = stdout, stderr

    def _run(self, input_data=None):
        if self.returncode is not None:
            return
        inp = input_data.decode("utf-8", "replace") if isinstance(input_data, bytes) else input_data
        try:
            rc, out, err = _TOOLS[self._name]([str(a) for a in list(self.args)[1:]], inp)
        except Exception as e:
            rc, out, err = 1, "", f"{self._name}: {type(e).__name__}: {e}"
        self.returncode = rc
        self._out, self._err = out, err

    def communicate(self, input=None, timeout=None):
        self._run(input)
        out = self._out if self._stdout_mode == subprocess.PIPE else None
        err = self._err if self._stderr_mode == subprocess.PIPE else None
        if not self._text:
            out = out.encode(self._enc) if out is not None else None
            err = err.encode(self._enc) if err is not None else None
        return out, err

    def wait(self, timeout=None):
        self._run()
        return self.returncode

    def poll(self):
        self._run()
        return self.returncode

    def kill(self):
        pass

    terminate = kill

    def send_signal(self, sig):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class _Popen(_RealPopen):
    def __new__(cls, args=None, *a, **kw):
        name = _virtual_name(args)
        if name:
            return _VirtualPopen(name, args, *a[:0], **kw)
        return super().__new__(cls)


def install() -> None:
    """Make the virtual tools visible. Idempotent."""
    global _installed
    if _installed:
        return
    shutil.which = _which
    subprocess.Popen = _Popen
    _installed = True
