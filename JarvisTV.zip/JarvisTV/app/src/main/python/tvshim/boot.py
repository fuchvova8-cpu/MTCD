"""Boot Mark LVII on Android, from an unmodified copy of the original.

Order matters:
  1. the extracted folder (writable) goes first on sys.path and becomes cwd, so
     every `Path(__file__).parent` in the original resolves to a place it can
     write config, memory, reports and plugins;
  2. the virtual command-line tools are installed (shutil.which / subprocess);
  3. `ui` is registered as tvshim.ui_android, so `from ui import JarvisUI` in
     the original main.py gets the TV class and never touches Qt;
  4. main.py is imported as a module and its own main() is run — the same
     function `python main.py` runs on a PC.
"""
from __future__ import annotations

import os
import sys
import threading
import time
import traceback

holder: dict = {}
_main = None


class _Tee:
    """stdout/stderr also go to <Jarvis>/jarvis.log, so a problem can be read
    from the TV's own file manager without a PC and logcat."""

    def __init__(self, stream, fh):
        self._s, self._f = stream, fh
        self._bol = True

    def write(self, text):
        try:
            # time-stamp every line in the file only, so "what happened at 00:26" can be read back
            out = []
            for chunk in text.splitlines(True):
                if self._bol and chunk.strip():
                    out.append(time.strftime("%H:%M:%S "))
                out.append(chunk)
                self._bol = chunk.endswith("\n")
            self._f.write("".join(out))
            self._f.flush()
        except Exception:
            pass
        return self._s.write(text) if self._s else len(text)

    def flush(self):
        try:
            self._f.flush()
            if self._s:
                self._s.flush()
        except Exception:
            pass

    def __getattr__(self, name):
        return getattr(self._s, name)


def _tee_log(path: str) -> None:
    try:
        if os.path.exists(path) and os.path.getsize(path) > 2_000_000:
            os.replace(path, path + ".1")
        fh = open(path, "a", encoding="utf-8", errors="replace")
        sys.stdout = _Tee(sys.stdout, fh)
        sys.stderr = _Tee(sys.stderr, fh)
    except Exception:
        pass


def run(jarvis_dir: str) -> None:
    global _main
    jarvis_dir = os.path.abspath(jarvis_dir)
    os.environ["JARVIS_HOME"] = jarvis_dir
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    # The original asks "is there a graphical session?" through these. The TV has
    # one (Android's), and every action that needs it goes through the virtual
    # tools below, so say yes rather than have it announce "no display".
    os.environ.setdefault("XDG_SESSION_TYPE", "x11")
    os.environ.setdefault("DISPLAY", ":0")
    # Android's own HOME is the app's private folder, which has no Desktop/Documents/Downloads. The
    # original saves screenshots and files under ~/..., so home is the visible Jarvis folder.
    os.environ["HOME"] = jarvis_dir
    for sub in ("Desktop", "Documents", "Downloads", "Pictures"):
        try:
            os.makedirs(os.path.join(jarvis_dir, sub), exist_ok=True)
        except OSError:
            pass

    _tee_log(os.path.join(jarvis_dir, "jarvis.log"))

    if jarvis_dir not in sys.path:
        sys.path.insert(0, jarvis_dir)
    os.chdir(jarvis_dir)

    from tvshim import toolbox
    toolbox.install()
    toolbox.rearm()

    from tvshim import ui_android
    sys.modules["ui"] = ui_android

    try:
        from tvshim import plugins_ext
        plugins_ext.install_loader_patch()
    except Exception:
        traceback.print_exc()

    import importlib
    _main = importlib.import_module("main")

    def _runner():
        try:
            _main.main()
        except SystemExit:
            pass
        except BaseException:
            traceback.print_exc()

    # main.main() builds JarvisUI, starts JarvisLive in its own thread, then
    # blocks in ui.root.mainloop() — which is ours and waits until shutdown().
    t = threading.Thread(target=_runner, name="jarvis-main", daemon=True)
    holder["thread"] = t
    t.start()


def shutdown() -> None:
    try:
        from tvshim import ui_android
        if ui_android.CURRENT:
            ui_android.CURRENT.root.quit()
    except Exception:
        pass
