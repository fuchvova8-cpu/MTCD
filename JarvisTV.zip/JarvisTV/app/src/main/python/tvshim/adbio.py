"""Input and screen access through the TV's own ADB daemon (loopback).

Android gives an ordinary app no way to press keys or tap in other apps. The
shell user can (`input`, `screencap`), and the TV's adbd lets the app speak to
it over 127.0.0.1 once "ADB debugging" / network debugging is on. Kotlin keeps
the connection (com.jarvis.tv.Adb, built on dadb); this module is the Python
face of it.
"""
from __future__ import annotations

import re
import threading
import time

from tvshim.bridge import kt, to_bytes

NO_ADB = ("ADB is not connected. On the TV: Settings > Device preferences > About, "
          "tap Build 7 times, then Developer options > enable USB debugging and "
          "network debugging; accept the 'Allow debugging' prompt for this app.")


class AdbUnavailable(RuntimeError):
    pass


def available() -> bool:
    try:
        return bool(kt().adbAvailable())
    except Exception:
        return False


def shell(cmd: str) -> str:
    try:
        out = kt().adbShell(cmd)
    except Exception as e:
        raise AdbUnavailable(f"{NO_ADB} ({e})")
    if out is None:          # Kotlin never returns null on success
        raise AdbUnavailable(NO_ADB)
    return str(out)


# ── screen ───────────────────────────────────────────────────────────────────
_size_cache: tuple[int, int] | None = None


def screen_size() -> tuple[int, int]:
    global _size_cache
    if _size_cache:
        return _size_cache
    w = h = 0
    try:
        out = shell("wm size")
        m = re.findall(r"(\d+)x(\d+)", out)
        if m:
            w, h = (int(v) for v in m[-1])
    except AdbUnavailable:
        pass
    if not w:
        try:
            sz = kt().screenSize()
            w, h = int(sz[0]), int(sz[1])
        except Exception:
            w, h = 1920, 1080
    _size_cache = (w, h)
    return _size_cache


def screencap_png() -> bytes:
    try:
        data = kt().adbScreencap()
    except Exception as e:
        raise AdbUnavailable(f"{NO_ADB} ({e})")
    raw = to_bytes(data)
    if not raw.startswith(b"\x89PNG"):
        raise AdbUnavailable("screencap returned no image")
    return raw


# ── input ────────────────────────────────────────────────────────────────────
def tap(x: int, y: int, source: str = "") -> None:
    shell(f"input {source} tap {int(x)} {int(y)}".replace("  ", " "))


def swipe(x1, y1, x2, y2, ms: int = 250) -> None:
    shell(f"input swipe {int(x1)} {int(y1)} {int(x2)} {int(y2)} {int(ms)}")


def keyevent(code, longpress: bool = False) -> None:
    shell(f"input keyevent {'--longpress ' if longpress else ''}{code}")


_ASCII_OK = re.compile(r"^[\x20-\x7e]*$")


def type_text(text: str) -> None:
    """Type text into the focused field.

    Plain ASCII goes through `input text`. Anything else (Cyrillic, emoji, a
    percent sign) cannot be typed that way, so it is put on the clipboard and
    pasted with KEYCODE_PASTE (279) — which is also how the original's own
    paste path works on a PC.
    """
    if not text:
        return
    if _ASCII_OK.match(text) and "%" not in text:
        for chunk in _chunks(text, 60):
            esc = chunk.replace("'", "'\\''").replace(" ", "%s")
            shell(f"input text '{esc}'")
        return
    kt().clipSet(text)
    time.sleep(0.12)
    keyevent(279)


def _chunks(s: str, n: int):
    for i in range(0, len(s), n):
        yield s[i:i + n]


# Android KEYCODE_* for the key names pyautogui / xdotool use.
KEYCODES: dict[str, int] = {
    "enter": 66, "return": 66, "tab": 61, "space": 62, " ": 62,
    "backspace": 67, "delete": 112, "del": 112, "esc": 111, "escape": 111,
    "up": 19, "down": 20, "left": 21, "right": 22,
    "home": 122, "end": 123, "pageup": 92, "pagedown": 93, "pgup": 92, "pgdn": 93,
    "insert": 124, "capslock": 115,
    "back": 4, "menu": 82, "tvhome": 3, "search": 84,
    "volumeup": 24, "volumedown": 25, "volumemute": 164,
    "playpause": 85, "nexttrack": 87, "prevtrack": 88, "stop": 86,
    "play": 126, "pause": 127, "mediastop": 86,
    "channelup": 166, "channeldown": 167, "tv": 170, "guide": 172,
    "info": 165, "ok": 23, "select": 23, "center": 23,
    "win": 3, "winleft": 3, "winright": 3, "command": 3, "apps": 187,
    "-": 69, "=": 70, "[": 71, "]": 72, "\\": 73, ";": 74, "'": 75, "/": 76,
    "@": 77, "+": 81, ",": 55, ".": 56, "`": 68,
}
for _i, _c in enumerate("abcdefghijklmnopqrstuvwxyz"):
    KEYCODES[_c] = 29 + _i
for _i in range(10):
    KEYCODES[str(_i)] = 7 + _i
    KEYCODES[f"num{_i}"] = 144 + _i
for _i in range(1, 13):
    KEYCODES[f"f{_i}"] = 131 + (_i - 1)

# Chords Android can express as a single key. (API 28 has no `input
# keycombination`, so arbitrary Ctrl/Alt chords cannot be sent.)
COMBOS: dict[tuple[str, ...], int] = {
    ("ctrl", "v"): 279, ("ctrl", "c"): 278, ("ctrl", "x"): 277,
    ("command", "v"): 279, ("command", "c"): 278, ("command", "x"): 277,
    ("alt", "f4"): 4, ("alt", "left"): 4, ("alt", "tab"): 187,
    ("win", "d"): 3, ("win", "tab"): 187, ("ctrl", "w"): 4,
    ("alt", "home"): 3, ("ctrl", "shift", "v"): 279,
}
MODIFIERS = {"ctrl", "control", "alt", "shift", "win", "winleft", "winright",
             "command", "option", "fn"}


def press_key(name: str) -> bool:
    key = str(name).lower()
    code = KEYCODES.get(key)
    if code is None:
        return False
    keyevent(code)
    return True


def chord(keys: list[str]) -> bool:
    ks = tuple(str(k).lower().replace("control", "ctrl") for k in keys)
    if ks in COMBOS:
        keyevent(COMBOS[ks])
        return True
    plain = [k for k in ks if k not in MODIFIERS]
    if len(plain) == 1 and len(ks) > 1 and set(ks) - set(plain) <= {"shift"}:
        # Shift+letter is just the capital letter.
        k = plain[0]
        if len(k) == 1 and k.isalpha():
            type_text(k.upper())
            return True
    if len(ks) == 1:
        return press_key(ks[0])
    return False
