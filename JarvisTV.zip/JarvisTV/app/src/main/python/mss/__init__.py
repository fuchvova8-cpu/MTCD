"""mss for Android TV — whole-screen capture through the TV's loopback ADB
(`screencap -p`). One monitor, like a TV. Same call shape the original uses:

    with mss.mss() as sct:            # or mss.MSS()
        shot = sct.grab(sct.monitors[1])
        png = mss.tools.to_png(shot.rgb, shot.size)
"""
from __future__ import annotations

import io

from tvshim import adbio

from . import tools  # noqa: F401  (so `import mss.tools` and `mss.tools` both work)


class ScreenShot:
    def __init__(self, width: int, height: int, rgb: bytes):
        self.size = (width, height)
        self.width, self.height = width, height
        self.left = self.top = 0
        self.rgb = rgb
        self.pos = (0, 0)

    @property
    def raw(self) -> bytes:
        return self.bgra

    @property
    def bgra(self) -> bytes:
        out = bytearray(self.width * self.height * 4)
        out[0::4] = self.rgb[2::3]
        out[1::4] = self.rgb[1::3]
        out[2::4] = self.rgb[0::3]
        out[3::4] = b"\xff" * (self.width * self.height)
        return bytes(out)


class ScreenShotError(Exception):
    pass


class MSS:
    def __init__(self, *a, **k):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def close(self):
        pass

    @property
    def monitors(self):
        w, h = adbio.screen_size()
        whole = {"left": 0, "top": 0, "width": w, "height": h}
        return [dict(whole), dict(whole)]

    def grab(self, monitor=None):
        from PIL import Image
        try:
            png = adbio.screencap_png()
        except Exception as e:
            raise ScreenShotError(str(e))
        img = Image.open(io.BytesIO(png)).convert("RGB")
        if isinstance(monitor, dict) and monitor.get("width") and \
                (monitor["width"], monitor["height"]) != img.size:
            l, t = monitor.get("left", 0), monitor.get("top", 0)
            img = img.crop((l, t, l + monitor["width"], t + monitor["height"]))
        return ScreenShot(img.width, img.height, img.tobytes())


def mss(*a, **k) -> MSS:
    return MSS()
