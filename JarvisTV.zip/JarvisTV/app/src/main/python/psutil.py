"""psutil for Android — the subset Mark LVII reads, from /proc and /sys.

Android 8+ hides most of /proc from ordinary apps (other apps' processes, and
on some firmware /proc/stat), so every reader degrades to a neutral value
instead of raising. Process lookups outside this app's own uid raise
NoSuchProcess/AccessDenied exactly as real psutil would.
"""
from __future__ import annotations

import os
import signal
import time
from collections import namedtuple

__version__ = "5.9.0"

STATUS_RUNNING = "running"
STATUS_SLEEPING = "sleeping"
STATUS_ZOMBIE = "zombie"
STATUS_STOPPED = "stopped"


class Error(Exception):
    pass


class NoSuchProcess(Error):
    def __init__(self, pid=None, name=None, msg=None):
        super().__init__(msg or f"process no longer exists (pid={pid})")
        self.pid, self.name = pid, name


class ZombieProcess(NoSuchProcess):
    pass


class AccessDenied(Error):
    def __init__(self, pid=None, name=None, msg=None):
        super().__init__(msg or f"access denied (pid={pid})")
        self.pid, self.name = pid, name


class TimeoutExpired(Error):
    pass


svmem = namedtuple("svmem", "total available percent used free active inactive buffers cached shared slab")
sdiskusage = namedtuple("sdiskusage", "total used free percent")
snetio = namedtuple("snetio", "bytes_sent bytes_recv packets_sent packets_recv errin errout dropin dropout")
shwtemp = namedtuple("shwtemp", "label current high critical")


def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def cpu_count(logical: bool = True):
    return os.cpu_count() or 1


_last_stat: tuple[float, float] | None = None


def _stat() -> tuple[float, float] | None:
    try:
        parts = _read("/proc/stat").splitlines()[0].split()[1:]
        vals = [float(v) for v in parts[:8]]
        idle = vals[3] + vals[4]
        return sum(vals), idle
    except Exception:
        return None


def cpu_percent(interval=None, percpu: bool = False):
    global _last_stat
    a = _stat()
    if a is None:                                  # /proc/stat is hidden: fall back to load
        try:
            return min(100.0, os.getloadavg()[0] / (os.cpu_count() or 1) * 100.0)
        except Exception:
            return 0.0
    if interval:
        time.sleep(interval)
        b = _stat() or a
        base = a
    else:
        b, base = a, _last_stat or a
    _last_stat = b
    dt = b[0] - base[0]
    di = b[1] - base[1]
    pct = 0.0 if dt <= 0 else max(0.0, min(100.0, (1.0 - di / dt) * 100.0))
    return [pct] * (os.cpu_count() or 1) if percpu else pct


def virtual_memory():
    info: dict[str, int] = {}
    try:
        for line in _read("/proc/meminfo").splitlines():
            k, _, v = line.partition(":")
            info[k] = int(v.split()[0]) * 1024
    except Exception:
        pass
    total = info.get("MemTotal", 0)
    avail = info.get("MemAvailable", info.get("MemFree", 0))
    used = max(0, total - avail)
    pct = (used / total * 100.0) if total else 0.0
    return svmem(total, avail, round(pct, 1), used, info.get("MemFree", 0), 0, 0,
                 info.get("Buffers", 0), info.get("Cached", 0), info.get("Shmem", 0), 0)


def boot_time() -> float:
    try:
        return time.time() - float(_read("/proc/uptime").split()[0])
    except Exception:
        return time.time() - time.monotonic()


def pids() -> list[int]:
    try:
        return sorted(int(d) for d in os.listdir("/proc") if d.isdigit())
    except Exception:
        return [os.getpid()]


def pid_exists(pid: int) -> bool:
    return os.path.exists(f"/proc/{int(pid)}")


def sensors_temperatures(fahrenheit: bool = False):
    out: dict[str, list] = {}
    base = "/sys/class/thermal"
    try:
        for zone in sorted(os.listdir(base)):
            if not zone.startswith("thermal_zone"):
                continue
            try:
                kind = _read(f"{base}/{zone}/type").strip() or zone
                cur = float(_read(f"{base}/{zone}/temp").strip())
            except Exception:
                continue
            cur = cur / 1000.0 if cur > 1000 else cur
            if fahrenheit:
                cur = cur * 9 / 5 + 32
            out.setdefault(kind, []).append(shwtemp(kind, cur, None, None))
    except Exception:
        pass
    return out


def sensors_battery():
    return None


def net_io_counters(pernic: bool = False):
    sent = recv = ps = pr = 0
    try:
        for line in _read("/proc/net/dev").splitlines()[2:]:
            name, _, rest = line.partition(":")
            if name.strip() == "lo":
                continue
            f = rest.split()
            recv += int(f[0]); pr += int(f[1]); sent += int(f[8]); ps += int(f[9])
    except Exception:
        pass
    return snetio(sent, recv, ps, pr, 0, 0, 0, 0)


def disk_usage(path: str):
    st = os.statvfs(path)
    total = st.f_blocks * st.f_frsize
    free = st.f_bavail * st.f_frsize
    used = total - st.f_bfree * st.f_frsize
    pct = (used / (used + free) * 100.0) if (used + free) else 0.0
    return sdiskusage(total, used, free, round(pct, 1))


class Process:
    def __init__(self, pid: int | None = None):
        self.pid = os.getpid() if pid is None else int(pid)
        if not os.path.exists(f"/proc/{self.pid}"):
            raise NoSuchProcess(self.pid)
        self.info: dict = {}

    def _stat_fields(self) -> list[str]:
        try:
            raw = _read(f"/proc/{self.pid}/stat")
        except PermissionError:
            raise AccessDenied(self.pid)
        except Exception:
            raise NoSuchProcess(self.pid)
        tail = raw[raw.rfind(")") + 2:].split()
        return tail                                  # [0]=state [1]=ppid ...

    def name(self) -> str:
        try:
            return _read(f"/proc/{self.pid}/comm").strip()
        except Exception:
            raw = _read(f"/proc/{self.pid}/stat")
            return raw[raw.find("(") + 1:raw.rfind(")")]

    def exe(self) -> str:
        try:
            return os.readlink(f"/proc/{self.pid}/exe")
        except PermissionError:
            raise AccessDenied(self.pid)
        except Exception:
            return ""

    def cmdline(self) -> list[str]:
        try:
            return [p for p in _read(f"/proc/{self.pid}/cmdline").split("\0") if p]
        except Exception:
            return []

    def ppid(self) -> int:
        return int(self._stat_fields()[1])

    def parent(self):
        try:
            return Process(self.ppid())
        except NoSuchProcess:
            return None

    def status(self) -> str:
        return {"R": STATUS_RUNNING, "S": STATUS_SLEEPING, "Z": STATUS_ZOMBIE,
                "T": STATUS_STOPPED}.get(self._stat_fields()[0], STATUS_SLEEPING)

    def is_running(self) -> bool:
        return os.path.exists(f"/proc/{self.pid}")

    def create_time(self) -> float:
        return time.time()

    def cpu_percent(self, interval=None) -> float:
        return 0.0

    def memory_info(self):
        return namedtuple("pmem", "rss vms")(0, 0)

    def username(self) -> str:
        return "app"

    def terminate(self):
        self._signal(signal.SIGTERM)

    def kill(self):
        self._signal(signal.SIGKILL)

    def _signal(self, sig):
        try:
            os.kill(self.pid, sig)
        except ProcessLookupError:
            raise NoSuchProcess(self.pid)
        except PermissionError:
            raise AccessDenied(self.pid)

    def wait(self, timeout=None):
        end = None if timeout is None else time.time() + timeout
        while self.is_running():
            if end is not None and time.time() > end:
                raise TimeoutExpired(f"timeout after {timeout}s")
            time.sleep(0.1)


def process_iter(attrs=None, ad_value=None):
    for pid in pids():
        try:
            p = Process(pid)
        except Error:
            continue
        if attrs:
            info = {}
            for a in attrs:
                try:
                    v = getattr(p, a)
                    info[a] = v() if callable(v) else v
                except Error:
                    info[a] = ad_value
                except Exception:
                    info[a] = ad_value
            p.info = info
        yield p
