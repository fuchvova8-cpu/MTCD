"""pyautogui for Android TV — input goes through the TV's loopback ADB.

Covers what Mark LVII calls: size, position, moveTo, click (and friends), dragTo,
scroll/hscroll, press, hotkey, write/typewrite, keyDown/keyUp, screenshot.
What Android cannot express is reported honestly rather than faked: hotkey()
returns without effect for a chord that has no single Android key, and
locateOnScreen raises ImageNotFoundException.
"""
from __future__ import annotations

import time
from collections import namedtuple

from tvshim import adbio

FAILSAFE = True
PAUSE = 0.1
MINIMUM_DURATION = 0.1
MINIMUM_SLEEP = 0.05
DARWIN_CATCH_UP_TIME = 0.0

Size = namedtuple("Size", "width height")
Point = namedtuple("Point", "x y")


class PyAutoGUIException(Exception):
    pass


class FailSafeException(PyAutoGUIException):
    pass


class ImageNotFoundException(PyAutoGUIException):
    pass


KEYBOARD_KEYS = sorted(adbio.KEYCODES)
KEY_NAMES = KEYBOARD_KEYS

_pos = [None, None]
_down = {"left": False}


def _pause():
    if PAUSE:
        time.sleep(min(PAUSE, 0.2))


def size() -> Size:
    w, h = adbio.screen_size()
    return Size(w, h)


resolution = size


def position(x=None, y=None) -> Point:
    w, h = adbio.screen_size()
    px = _pos[0] if _pos[0] is not None else w // 2
    py = _pos[1] if _pos[1] is not None else h // 2
    return Point(px, py)


def onScreen(x, y=None) -> bool:
    if y is None and isinstance(x, (tuple, list)):
        x, y = x
    w, h = adbio.screen_size()
    return 0 <= x < w and 0 <= y < h


def _xy(x, y):
    if isinstance(x, (tuple, list)) and y is None:
        x, y = x
    cur = position()
    return int(cur.x if x is None else x), int(cur.y if y is None else y)


def moveTo(x=None, y=None, duration=0.0, tween=None, _pause=True, **kw):
    """Android has no visible-cursor API for other apps; the position is
    remembered so the next click/scroll lands where the caller asked."""
    _pos[0], _pos[1] = _xy(x, y)
    if duration:
        time.sleep(min(float(duration), 0.5))


def moveRel(xOffset=None, yOffset=None, duration=0.0, **kw):
    cur = position()
    moveTo(cur.x + int(xOffset or 0), cur.y + int(yOffset or 0), duration)


move = moveRel


def click(x=None, y=None, clicks=1, interval=0.0, button="left", duration=0.0, **kw):
    px, py = _xy(x, y)
    _pos[0], _pos[1] = px, py
    if str(button).lower() == "right":
        adbio.keyevent(4)                      # a right click is Back on Android
        _pause()
        return
    for i in range(max(1, int(clicks))):
        adbio.tap(px, py)
        if interval and i + 1 < clicks:
            time.sleep(float(interval))
    _pause()


def doubleClick(x=None, y=None, interval=0.0, button="left", **kw):
    click(x, y, clicks=2, interval=interval or 0.08, button=button)


def tripleClick(x=None, y=None, interval=0.0, button="left", **kw):
    click(x, y, clicks=3, interval=interval or 0.08, button=button)


def rightClick(x=None, y=None, **kw):
    click(x, y, button="right")


def middleClick(x=None, y=None, **kw):
    click(x, y, button="middle")


def mouseDown(x=None, y=None, button="left", **kw):
    moveTo(x, y)
    _down["left"] = True


def mouseUp(x=None, y=None, button="left", **kw):
    _down["left"] = False


def dragTo(x=None, y=None, duration=0.0, button="left", **kw):
    sx, sy = position()
    ex, ey = _xy(x, y)
    adbio.swipe(sx, sy, ex, ey, max(150, int(float(duration) * 1000)))
    _pos[0], _pos[1] = ex, ey
    _pause()


def dragRel(xOffset=0, yOffset=0, duration=0.0, button="left", **kw):
    cur = position()
    dragTo(cur.x + int(xOffset), cur.y + int(yOffset), duration, button)


drag = dragRel


def scroll(clicks, x=None, y=None, **kw):
    """Positive = wheel up = the content moves down = a downward swipe."""
    px, py = _xy(x, y)
    dist = max(60, min(700, abs(int(clicks)) * 120))
    sign = 1 if int(clicks) > 0 else -1
    adbio.swipe(px, py - sign * dist // 2, px, py + sign * dist // 2, 250)
    _pause()


vscroll = scroll


def hscroll(clicks, x=None, y=None, **kw):
    px, py = _xy(x, y)
    dist = max(60, min(900, abs(int(clicks)) * 120))
    sign = 1 if int(clicks) > 0 else -1
    adbio.swipe(px - sign * dist // 2, py, px + sign * dist // 2, py, 250)
    _pause()


def press(keys, presses=1, interval=0.0, **kw):
    if isinstance(keys, str):
        keys = [keys]
    for _ in range(max(1, int(presses))):
        for k in keys:
            if not adbio.press_key(k):
                print(f"[pyautogui] no Android key for {k!r}")
        if interval:
            time.sleep(float(interval))
    _pause()


def keyDown(key, **kw):
    pass                                          # a key press is atomic on Android


def keyUp(key, **kw):
    adbio.press_key(key)


def hotkey(*args, interval=0.0, **kw):
    keys = list(args[0]) if len(args) == 1 and isinstance(args[0], (list, tuple)) else list(args)
    if not adbio.chord(keys):
        print(f"[pyautogui] chord {'+'.join(map(str, keys))} has no Android equivalent")
    _pause()


def write(message, interval=0.0, **kw):
    adbio.type_text(str(message))
    _pause()


typewrite = write


def screenshot(imageFilename=None, region=None):
    import io

    from PIL import Image
    img = Image.open(io.BytesIO(adbio.screencap_png())).convert("RGB")
    if region:
        l, t, w, h = region
        img = img.crop((l, t, l + w, t + h))
    if imageFilename:
        img.save(imageFilename)
    return img


def locateOnScreen(*a, **k):
    raise ImageNotFoundException("image search is not available on this device")


locateCenterOnScreen = locateAllOnScreen = locate = locateOnScreen


def pixel(x, y):
    return screenshot().getpixel((int(x), int(y)))


def sleep(seconds):
    time.sleep(seconds)


def alert(text="", title="", button="OK"):
    return button


def confirm(text="", title="", buttons=("OK", "Cancel")):
    return buttons[0]


def prompt(text="", title="", default=""):
    return default
