"""pyperclip for Android TV — the system clipboard through the Kotlin bridge."""
from __future__ import annotations

from tvshim.bridge import kt


class PyperclipException(RuntimeError):
    pass


def copy(text):
    kt().clipSet("" if text is None else str(text))


def paste() -> str:
    out = kt().clipGet()
    return "" if out is None else str(out)


def is_available() -> bool:
    return True
