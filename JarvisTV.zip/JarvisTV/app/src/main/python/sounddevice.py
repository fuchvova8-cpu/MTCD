"""sounddevice for Android TV.

Same surface Mark LVII uses (InputStream / RawInputStream / RawOutputStream /
OutputStream / play / wait / stop / query_devices / query_hostapis), backed by
Android's AudioRecord and AudioTrack through com.jarvis.tv.MicBridge and
com.jarvis.tv.SpeakerBridge.

Input is callback-driven exactly like PortAudio: `callback(indata, frames,
time, status)` runs on a worker thread. Output `write()` blocks until the
samples are accepted by the hardware buffer, so the sink is rate-limited by the
real clock the way the original's probe expects.
"""
from __future__ import annotations

import threading
import time

import numpy as np

from tvshim.bridge import jclass, to_bytes


class PortAudioError(Exception):
    pass


class CallbackStop(Exception):
    pass


class CallbackAbort(Exception):
    pass


class CallbackFlags:
    """Falsy when nothing is wrong, like PortAudio's flags object."""
    def __bool__(self):
        return False

    def __str__(self):
        return ""


class _Default:
    device = (None, None)
    samplerate = None
    channels = (None, None)
    dtype = ("int16", "int16")
    latency = ("low", "low")


default = _Default()

_DEVICES = [
    {"name": "Android Microphone", "index": 0, "hostapi": 0,
     "max_input_channels": 1, "max_output_channels": 0,
     "default_low_input_latency": 0.02, "default_low_output_latency": 0.0,
     "default_high_input_latency": 0.1, "default_high_output_latency": 0.0,
     "default_samplerate": 16000.0},
    {"name": "Android Speaker (TV)", "index": 1, "hostapi": 0,
     "max_input_channels": 0, "max_output_channels": 2,
     "default_low_input_latency": 0.0, "default_low_output_latency": 0.05,
     "default_high_input_latency": 0.0, "default_high_output_latency": 0.2,
     "default_samplerate": 24000.0},
]


def query_devices(device=None, kind=None):
    if device is None and kind is None:
        return list(_DEVICES)
    if device is None:
        want = "max_input_channels" if kind == "input" else "max_output_channels"
        return next(d for d in _DEVICES if d[want] > 0)
    if isinstance(device, int):
        return _DEVICES[device]
    for d in _DEVICES:
        if str(device).lower() in d["name"].lower():
            return d
    raise PortAudioError(f"No such device: {device!r}")


def query_hostapis(index=None):
    apis = [{"name": "Android", "devices": [0, 1],
             "default_input_device": 0, "default_output_device": 1}]
    return apis if index is None else apis[index]


def check_input_settings(*a, **k):
    return None


def check_output_settings(*a, **k):
    return None


def _status():
    return CallbackFlags()


# ── input ────────────────────────────────────────────────────────────────────
class _InputBase:
    _raw = False

    def __init__(self, samplerate=None, blocksize=None, device=None,
                 channels=None, dtype=None, latency=None, extra_settings=None,
                 callback=None, finished_callback=None, **_ignored):
        self.samplerate = float(samplerate or 16000)
        self.blocksize = int(blocksize or 1024)
        self.channels = int(channels or 1)
        self.dtype = str(dtype or "int16")
        self.device = device
        self.callback = callback
        self.finished_callback = finished_callback
        self._mic = None
        self._thread = None
        self._run = False
        self.active = False
        self.closed = False
        self.latency = 0.05

    # PortAudio's context-manager protocol starts on enter, stops+closes on exit.
    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc):
        self.stop()
        self.close()

    def start(self):
        if self._run:
            return
        try:
            self._mic = jclass("com.jarvis.tv.MicBridge")(int(self.samplerate), self.blocksize)
            self._mic.start()
        except Exception as e:
            self._mic = None
            raise PortAudioError(f"Android microphone could not be opened: {e}")
        self._run = True
        self.active = True
        self._thread = threading.Thread(target=self._pump, name="tvshim-mic", daemon=True)
        self._thread.start()

    def _pump(self):
        try:
            while self._run:
                try:
                    data = self._mic.read()
                except Exception:
                    break
                if data is None:
                    break
                raw = to_bytes(data)
                if not raw:
                    continue
                if self._raw:
                    indata, frames = raw, len(raw) // (2 * self.channels)
                else:
                    arr = np.frombuffer(raw, dtype=np.int16).reshape(-1, self.channels)
                    if self.dtype == "float32":
                        arr = arr.astype(np.float32) / 32768.0
                    indata, frames = arr, arr.shape[0]
                if self.callback is None:
                    continue
                try:
                    self.callback(indata, frames, None, _status())
                except CallbackStop:
                    break
                except CallbackAbort:
                    break
                except Exception as e:
                    print(f"[sounddevice] input callback error: {type(e).__name__}: {e}")
        finally:
            self.active = False
            if self.finished_callback:
                try:
                    self.finished_callback()
                except Exception:
                    pass

    def stop(self, ignore_errors=True):
        self._run = False
        mic = self._mic
        if mic is not None:
            try:
                mic.stop()
            except Exception:
                pass
        t = self._thread
        if t is not None and t is not threading.current_thread():
            t.join(timeout=1.0)
        self.active = False

    def abort(self, ignore_errors=True):
        self.stop()

    def close(self, ignore_errors=True):
        self.stop()
        mic, self._mic = self._mic, None
        if mic is not None:
            try:
                mic.release()
            except Exception:
                pass
        self.closed = True

    @property
    def stopped(self):
        return not self.active


class InputStream(_InputBase):
    pass


class RawInputStream(_InputBase):
    _raw = True


# ── output ───────────────────────────────────────────────────────────────────
class RawOutputStream:
    _numpy = False

    def __init__(self, samplerate=None, blocksize=None, device=None,
                 channels=None, dtype=None, latency=None, extra_settings=None,
                 callback=None, finished_callback=None, **_ignored):
        if callback is not None:
            raise PortAudioError("callback output streams are not used by Mark LVII")
        self.samplerate = float(samplerate or 24000)
        self.blocksize = int(blocksize or 1024)
        self.channels = int(channels or 1)
        self.dtype = str(dtype or "int16")
        self.device = device
        self._spk = None
        self.active = False
        self.closed = False
        self._lock = threading.Lock()

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc):
        self.stop()
        self.close()

    def start(self):
        with self._lock:
            if self._spk is not None:
                self.active = True
                return
            try:
                self._spk = jclass("com.jarvis.tv.SpeakerBridge")(
                    int(self.samplerate), self.channels, self.blocksize)
                self._spk.start()
            except Exception as e:
                self._spk = None
                raise PortAudioError(f"Android audio output could not be opened: {e}")
            self.active = True

    @property
    def latency(self):
        spk = self._spk
        try:
            return float(spk.latencySeconds()) if spk is not None else 0.0
        except Exception:
            return 0.0

    def _to_pcm16(self, data) -> bytes:
        if self._numpy or isinstance(data, np.ndarray):
            arr = np.asarray(data)
            if arr.dtype.kind == "f":
                arr = np.clip(arr, -1.0, 1.0) * 32767.0
            return arr.astype(np.int16).tobytes()
        return bytes(data)

    def write(self, data):
        spk = self._spk
        if spk is None:
            raise PortAudioError("stream is not started")
        pcm = self._to_pcm16(data)
        if pcm:
            spk.write(pcm)           # blocks until the hardware accepts it
        return False                 # "underflowed" flag

    def stop(self, ignore_errors=True):
        spk = self._spk
        if spk is not None:
            try:
                spk.stop()
            except Exception:
                pass
        self.active = False

    def abort(self, ignore_errors=True):
        spk = self._spk
        if spk is not None:
            try:
                spk.abort()
            except Exception:
                pass
        self.active = False

    def close(self, ignore_errors=True):
        with self._lock:
            spk, self._spk = self._spk, None
        if spk is not None:
            try:
                spk.release()
            except Exception:
                pass
        self.active = False
        self.closed = True

    @property
    def stopped(self):
        return not self.active


class OutputStream(RawOutputStream):
    _numpy = True


# ── one-shot play ────────────────────────────────────────────────────────────
_play_lock = threading.Lock()
_play_thread: threading.Thread | None = None
_play_stream: RawOutputStream | None = None


def play(data, samplerate=None, mapping=None, blocking=False, loop=False, **kw):
    """Play an array and return at once (like sounddevice); wait() joins it."""
    global _play_thread, _play_stream
    stop()
    arr = np.asarray(data)
    channels = arr.shape[1] if arr.ndim > 1 else 1
    rate = int(samplerate or 24000)
    stream = OutputStream(samplerate=rate, channels=channels, dtype="int16")
    stream.start()

    def _run():
        try:
            chunk = rate  # one second per write keeps abort() responsive enough
            for i in range(0, len(arr), chunk):
                if stream._spk is None:
                    break
                stream.write(arr[i:i + chunk])
        except Exception as e:
            print(f"[sounddevice] play error: {type(e).__name__}: {e}")
        finally:
            try:
                stream.stop()
                stream.close()
            except Exception:
                pass

    t = threading.Thread(target=_run, name="tvshim-play", daemon=True)
    with _play_lock:
        _play_thread, _play_stream = t, stream
    t.start()
    if blocking:
        wait()


def wait(ignore_errors=True):
    t = _play_thread
    if t is not None and t is not threading.current_thread():
        t.join()


def stop(ignore_errors=True):
    global _play_thread, _play_stream
    with _play_lock:
        t, s = _play_thread, _play_stream
        _play_thread = _play_stream = None
    if s is not None:
        try:
            s.abort()
            s.close()
        except Exception:
            pass
    if t is not None and t is not threading.current_thread():
        t.join(timeout=1.0)


def get_status():
    return _status()


def get_stream():
    return _play_stream
