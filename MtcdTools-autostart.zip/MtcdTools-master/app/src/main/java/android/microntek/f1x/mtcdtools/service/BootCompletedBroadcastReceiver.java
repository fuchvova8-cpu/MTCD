package android.microntek.f1x.mtcdtools.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Single entry point for every autostart trigger declared in AndroidManifest.xml
 * (cold boot, quick boot, MTC head unit wake-up, power/media/network events, key press...).
 *
 * "Boot like" triggers start the service AND execute the autorun list.
 * All other triggers only make sure that the service is alive.
 */
public class BootCompletedBroadcastReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        final String action = intent == null ? null : intent.getAction();

        Intent startServiceIntent = new Intent(context, MtcdService.class);
        startServiceIntent.setAction(isBootLikeAction(action) ? MtcdService.ACTION_AUTORUN : MtcdService.ACTION_KEEP_ALIVE);
        startServiceIntent.putExtra(MtcdService.EXTRA_TRIGGER, action);

        try {
            context.startService(startServiceIntent);
        } catch (RuntimeException e) {
            // e.g. a restriction of the firmware; the AlarmManager keep-alive will retry later
            Log.w(TAG, "Could not start MtcdService from trigger " + action, e);
        }
    }

    static boolean isBootLikeAction(String action) {
        if (action == null) {
            return false;
        }

        switch (action) {
            case Intent.ACTION_BOOT_COMPLETED:
            case "android.intent.action.LOCKED_BOOT_COMPLETED":
            case "android.intent.action.QUICKBOOT_POWERON":
            case "com.htc.intent.action.QUICKBOOT_POWERON":
            case "android.intent.action.REBOOT":
            case "com.microntek.bootcheck":
                return true;

            default:
                return false;
        }
    }

    private static final String TAG = "MtcdBootReceiver";
}
