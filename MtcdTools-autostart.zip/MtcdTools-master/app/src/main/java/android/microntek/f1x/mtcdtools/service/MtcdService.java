package android.microntek.f1x.mtcdtools.service;

import android.app.Notification;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.os.SystemClock;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

import android.microntek.f1x.mtcdtools.R;
import android.microntek.f1x.mtcdtools.service.configuration.Configuration;
import android.microntek.f1x.mtcdtools.service.dispatching.DispatchingIndicationPlayer;
import android.microntek.f1x.mtcdtools.service.dispatching.KeysSequenceDispatcher;
import android.microntek.f1x.mtcdtools.service.input.DiagLog;
import android.microntek.f1x.mtcdtools.service.input.KeyInterceptor;
import android.microntek.f1x.mtcdtools.service.input.KeysSequenceBinding;
import android.microntek.f1x.mtcdtools.service.input.PX3PressedKeysSequenceManager;
import android.microntek.f1x.mtcdtools.service.input.PX5PressedKeysSequenceManager;
import android.microntek.f1x.mtcdtools.service.input.PressedKeysSequenceManager;
import android.microntek.f1x.mtcdtools.service.dispatching.NamedObjectDispatcher;
import android.microntek.f1x.mtcdtools.service.storage.AutorunStorage;
import android.microntek.f1x.mtcdtools.service.storage.FileReader;
import android.microntek.f1x.mtcdtools.service.storage.FileWriter;
import android.microntek.f1x.mtcdtools.service.storage.KeysSequenceBindingsStorage;
import android.microntek.f1x.mtcdtools.service.storage.NamedObjectsStorage;
import android.microntek.f1x.mtcdtools.service.storage.exceptions.DuplicatedEntryException;
import android.microntek.f1x.mtcdtools.service.storage.exceptions.EntryCreationFailed;
import android.microntek.f1x.mtcdtools.utils.PlatformChecker;

import org.json.JSONException;

import java.io.IOException;
import java.util.List;

/**
 * Created by f1x on 2016-08-03.
 */
public class MtcdService extends android.app.Service {
    @Override
    public void onCreate() {
        super.onCreate();

        mForceRestart = false;
        mServiceInitialized = false;
        mInitFailed = false;
        mAutorunDispatched = false;
        mLastAutorunTimeMs = 0;

        FileReader fileReader = new FileReader(this);
        FileWriter fileWriter = new FileWriter(this);
        mNamedObjectsStorage = new NamedObjectsStorage(fileReader, fileWriter);
        mKeysSequenceBindingsStorage = new KeysSequenceBindingsStorage(fileReader, fileWriter);
        mAutorunStorage = new AutorunStorage(fileReader, fileWriter);
        mConfiguration = new Configuration(this.getSharedPreferences(APP_NAME, Context.MODE_PRIVATE));
        mPressedKeysSequenceManager = PlatformChecker.isPX5Platform() ? new PX5PressedKeysSequenceManager(mConfiguration) : new PX3PressedKeysSequenceManager(mConfiguration, this);
        mPressedKeysSequenceManager.setKeyInterceptor(mKeyInterceptor);
        DiagLog.add("service created, PX5 platform=" + PlatformChecker.isPX5Platform());
        mNamedObjectsDispatcher = new NamedObjectDispatcher(mNamedObjectsStorage);
        mDispatchingIndicationPlayer = new DispatchingIndicationPlayer(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if(mForceRestart) {
            MtcdServiceWatchdog.scheduleServiceRestart(this);
        }

        if(mServiceInitialized) {
            unregisterReceiver(mScreenOnBroadcastReceiver);
            mPressedKeysSequenceManager.destroy();
            mServiceInitialized = false;
        }

        mDispatchingIndicationPlayer.release();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mServiceBinder;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        // The user swiped the app away from "recent apps": come back.
        MtcdServiceWatchdog.scheduleServiceRestart(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);

        // intent == null when the system re-delivers a START_STICKY service after the process was killed
        final boolean autorunRequested = intent != null && ACTION_AUTORUN.equals(intent.getAction());

        MtcdServiceWatchdog.scheduleKeepAlive(this);

        if(mServiceInitialized) {
            if(autorunRequested) {
                dispatchAutorun();
            }

            return START_STICKY;
        }

        if(mInitFailed) {
            return START_STICKY;
        }

        try {
            mNamedObjectsStorage.read();
            mKeysSequenceBindingsStorage.read();
            mAutorunStorage.read();

            mPressedKeysSequenceManager.init();
            mPressedKeysSequenceManager.pushListener(new KeysSequenceDispatcher(this, mKeysSequenceBindingsStorage, mNamedObjectsDispatcher, mDispatchingIndicationPlayer));
            startForeground(1555, createNotification());
            registerReceiver(mScreenOnBroadcastReceiver, new IntentFilter(Intent.ACTION_SCREEN_ON));
            mForceRestart = true;
            mServiceInitialized = true;
            AccessibilityAutoEnabler.tryEnable(this);

            if(autorunRequested) {
                dispatchAutorun();
            }
        } catch (JSONException | IOException | DuplicatedEntryException | EntryCreationFailed e) {
            e.printStackTrace();
            mInitFailed = true;
            Toast.makeText(this, e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
        }

        return START_STICKY;
    }

    /**
     * Several autostart triggers can fire one after another (BOOT_COMPLETED, QUICKBOOT_POWERON, SCREEN_ON...).
     * The autorun list is executed only once in a short time window.
     */
    private void dispatchAutorun() {
        final long now = SystemClock.elapsedRealtime();

        if(mAutorunDispatched && now - mLastAutorunTimeMs < AUTORUN_DEBOUNCE_MS) {
            return;
        }

        mAutorunDispatched = true;
        mLastAutorunTimeMs = now;
        mNamedObjectsDispatcher.dispatch(mAutorunStorage.getItems(), this);
    }

    private Notification createNotification() {
        return new NotificationCompat.Builder(this)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.MtcdServiceDescription))
                .setSmallIcon(R.drawable.service_notification_icon)
                .setOngoing(true)
                .build();
    }

    private boolean mForceRestart;
    private boolean mServiceInitialized;
    private boolean mInitFailed;
    private boolean mAutorunDispatched;
    private long mLastAutorunTimeMs;
    private NamedObjectsStorage mNamedObjectsStorage;
    private KeysSequenceBindingsStorage mKeysSequenceBindingsStorage;
    private AutorunStorage mAutorunStorage;
    private PressedKeysSequenceManager mPressedKeysSequenceManager;
    private Configuration mConfiguration;
    private NamedObjectDispatcher mNamedObjectsDispatcher;
    private DispatchingIndicationPlayer mDispatchingIndicationPlayer;

    private final ServiceBinder mServiceBinder = new ServiceBinder() {
        @Override
        public KeysSequenceBindingsStorage getKeysSequenceBindingsStorage() {
            return mKeysSequenceBindingsStorage;
        }

        @Override
        public NamedObjectsStorage getNamedObjectsStorage() {
            return mNamedObjectsStorage;
        }

        @Override
        public PressedKeysSequenceManager getPressedKeysSequenceManager() {
            return mPressedKeysSequenceManager;
        }

        @Override
        public Configuration getConfiguration() {
            return mConfiguration;
        }

        @Override
        public NamedObjectDispatcher getNamedObjectsDispatcher() {
            return mNamedObjectsDispatcher;
        }

        @Override
        public AutorunStorage getAutorunStorage() {
            return mAutorunStorage;
        }
    };

    private final BroadcastReceiver mScreenOnBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(Intent.ACTION_SCREEN_ON.equals(intent.getAction())) {
                dispatchAutorun();
            }
        }
    };

    /**
     * Key interception: a key that takes part in any of the user's bindings is consumed by MtcdTools,
     * so the stock firmware function assigned to this key is not executed.
     */
    private final KeyInterceptor mKeyInterceptor = new KeyInterceptor() {
        @Override
        public boolean shouldIntercept(int keyCode) {
            for(KeysSequenceBinding binding : mKeysSequenceBindingsStorage.getItems().values()) {
                List<Integer> keysSequence = binding.getKeysSequence();

                if(keysSequence.contains(keyCode)) {
                    return true;
                }
            }

            return false;
        }
    };

    public static final String ACTION_AUTORUN = "android.microntek.f1x.mtcdtools.action.autorun";
    public static final String ACTION_KEEP_ALIVE = "android.microntek.f1x.mtcdtools.action.keepalive";
    public static final String EXTRA_TRIGGER = "android.microntek.f1x.mtcdtools.extra.trigger";
    private static final long AUTORUN_DEBOUNCE_MS = 20 * 1000;
    private static final String APP_NAME = "MtcdTools";
}
