package android.microntek.f1x.mtcdtools.service.input;

import android.os.SystemClock;

import java.util.LinkedList;

/** Tiny in-memory event log (last 150 lines) shown by DiagActivity. */
public final class DiagLog {
    private DiagLog() {}

    public static synchronized void add(String text) {
        sLines.add((SystemClock.uptimeMillis() % 1000000) + "  " + text);
        while(sLines.size() > 150) {
            sLines.removeFirst();
        }
    }

    public static synchronized String dump() {
        StringBuilder builder = new StringBuilder();
        for(int i = sLines.size() - 1; i >= 0; --i) {
            builder.append(sLines.get(i)).append('\n');
        }
        return builder.toString();
    }

    public static synchronized void clear() {
        sLines.clear();
    }

    private static final LinkedList<String> sLines = new LinkedList<>();
}
