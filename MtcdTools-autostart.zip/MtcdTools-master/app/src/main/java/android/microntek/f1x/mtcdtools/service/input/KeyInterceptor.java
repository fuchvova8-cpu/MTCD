package android.microntek.f1x.mtcdtools.service.input;

/**
 * Decides whether a raw hardware key code should be consumed by MtcdTools
 * (i.e. hidden from the stock firmware handlers) or just observed.
 */
public interface KeyInterceptor {
    boolean shouldIntercept(int keyCode);
}
