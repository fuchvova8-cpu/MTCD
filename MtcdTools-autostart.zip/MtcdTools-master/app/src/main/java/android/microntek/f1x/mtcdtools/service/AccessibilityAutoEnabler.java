package android.microntek.f1x.mtcdtools.service;

import android.content.Context;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;

/**
 * Enables KeyInterceptAccessibilityService without opening the settings screen.
 * Works only if the permission WRITE_SECURE_SETTINGS was granted, e.g.:
 *   adb shell pm grant android.microntek.f1x.mtcdtools android.permission.WRITE_SECURE_SETTINGS
 * (or the APK is installed as a system app). Otherwise it silently does nothing.
 */
class AccessibilityAutoEnabler {
    static void tryEnable(Context context) {
        try {
            final String component = context.getPackageName() + "/" + KeyInterceptAccessibilityService.class.getName();
            final String enabled = Settings.Secure.getString(context.getContentResolver(), "enabled_accessibility_services");

            if(enabled != null && enabled.contains(component)) {
                return;
            }

            final String newValue = TextUtils.isEmpty(enabled) ? component : enabled + ":" + component;
            Settings.Secure.putString(context.getContentResolver(), "enabled_accessibility_services", newValue);
            Settings.Secure.putInt(context.getContentResolver(), "accessibility_enabled", 1);
        } catch (SecurityException e) {
            Log.i("MtcdTools", "WRITE_SECURE_SETTINGS not granted, enable the accessibility service manually");
        } catch (RuntimeException e) {
            Log.w("MtcdTools", "Could not enable accessibility service", e);
        }
    }
}
