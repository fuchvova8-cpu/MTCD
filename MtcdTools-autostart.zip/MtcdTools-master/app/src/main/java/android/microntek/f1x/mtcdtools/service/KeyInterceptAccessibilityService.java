package android.microntek.f1x.mtcdtools.service;

import android.accessibilityservice.AccessibilityService;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

import android.microntek.f1x.mtcdtools.service.input.DiagLog;
import android.microntek.f1x.mtcdtools.service.input.KeySuppressor;

/**
 * Consumes the Android key events produced by the stock firmware for keys bound in MtcdTools.
 * Must be enabled once in Settings -> Accessibility (or automatically, see AccessibilityAutoEnabler).
 */
public class KeyInterceptAccessibilityService extends AccessibilityService {
    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        final boolean consume = KeySuppressor.shouldConsume(event);
        DiagLog.add("AND " + KeyEvent.keyCodeToString(event.getKeyCode()) + " action=" + event.getAction()
                + " repeat=" + event.getRepeatCount() + " dev=" + event.getDeviceId() + " consumed=" + consume);
        return consume;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        DiagLog.add("ACC service connected");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }
}
