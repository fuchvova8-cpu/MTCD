package android.microntek.f1x.mtcdtools.activities;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import android.microntek.f1x.mtcdtools.service.MtcdService;
import android.microntek.f1x.mtcdtools.service.input.DiagLog;

/** Shows the newest key events first: RAW = MTC key broadcast, AND = Android KeyEvent seen by the accessibility service. */
public class DiagActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button clear = new Button(this);
        clear.setText("Clear");
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DiagLog.clear();
                refresh();
            }
        });
        buttons.addView(clear);
        root.addView(buttons);

        mText = new TextView(this);
        mText.setTypeface(Typeface.MONOSPACE);
        mText.setTextSize(13);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(mText);
        root.addView(scroll);
        setContentView(root);

        startService(new android.content.Intent(this, MtcdService.class));
    }

    @Override
    protected void onResume() {
        super.onResume();
        mHandler.post(mRefresh);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mHandler.removeCallbacks(mRefresh);
    }

    private void refresh() {
        mText.setText(DiagLog.dump());
    }

    private final Handler mHandler = new Handler();
    private final Runnable mRefresh = new Runnable() {
        @Override
        public void run() {
            refresh();
            mHandler.postDelayed(this, 500);
        }
    };

    private TextView mText;
}
