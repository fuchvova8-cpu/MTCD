package android.microntek.f1x.mtcdtools.service;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;

/**
 * Created by f1x on 2016-08-16.
 */
class MtcdServiceWatchdog {
    public static void scheduleServiceRestart(Context context) {
        // WORKAROUND: Do not know why MTCD Android does not respect START_STICKY

        Intent restartServiceIntent = new Intent(context, MtcdService.class);
        restartServiceIntent.setPackage(context.getPackageName());

        PendingIntent restartServicePendingIntent = PendingIntent.getService(context, 1555, restartServiceIntent, PendingIntent.FLAG_ONE_SHOT);
        AlarmManager alarmManager = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + SERVICE_RESTART_DELAY_MS, restartServicePendingIntent);
    }

    /**
     * Periodic "are you alive?" alarm. If the firmware killed the service (e.g. while the head unit was
     * going to sleep) the alarm survives and starts it again. ELAPSED_REALTIME (not *_WAKEUP) is used on
     * purpose: the alarm never wakes a sleeping head unit, so it does not drain the car battery.
     */
    public static void scheduleKeepAlive(Context context) {
        Intent keepAliveIntent = new Intent(context, MtcdService.class);
        keepAliveIntent.setAction(MtcdService.ACTION_KEEP_ALIVE);

        PendingIntent keepAlivePendingIntent = PendingIntent.getService(context, KEEP_ALIVE_REQUEST_CODE, keepAliveIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarmManager = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        alarmManager.setRepeating(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + KEEP_ALIVE_INTERVAL_MS, KEEP_ALIVE_INTERVAL_MS, keepAlivePendingIntent);
    }

    private static final int SERVICE_RESTART_DELAY_MS = 100;
    private static final int KEEP_ALIVE_REQUEST_CODE = 1556;
    private static final long KEEP_ALIVE_INTERVAL_MS = 2 * 60 * 1000;
}
