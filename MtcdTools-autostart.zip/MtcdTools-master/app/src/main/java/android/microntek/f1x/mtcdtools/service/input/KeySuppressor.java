package android.microntek.f1x.mtcdtools.service.input;

import android.os.SystemClock;
import android.view.KeyEvent;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Bridge between the raw MTC key broadcast and the accessibility service.
 *
 * When a hardware / steering wheel key that is used in a MtcdTools binding is received, a short
 * "suppress window" is opened. The accessibility service consumes every Android KeyEvent that the
 * firmware injects in that window (and the matching key-up / long-press repeats), so the stock
 * function does not run.
 */
public final class KeySuppressor {
    private KeySuppressor() {}

    public static void onBoundKeyPressed() {
        sSuppressUntilMs = SystemClock.uptimeMillis() + SUPPRESS_WINDOW_MS;
    }

    public static boolean shouldConsume(KeyEvent event) {
        final int keyCode = event.getKeyCode();
        final boolean inWindow = SystemClock.uptimeMillis() <= sSuppressUntilMs;

        if(event.getAction() == KeyEvent.ACTION_DOWN) {
            if(inWindow || sConsumedKeys.contains(keyCode)) {
                sConsumedKeys.add(keyCode);
                return true;
            }

            return false;
        }

        // key up: consume it if its down was consumed
        return sConsumedKeys.remove(keyCode);
    }

    private static final long SUPPRESS_WINDOW_MS = 600;
    private static volatile long sSuppressUntilMs = 0;
    private static final Set<Integer> sConsumedKeys = Collections.synchronizedSet(new HashSet<Integer>());
}
